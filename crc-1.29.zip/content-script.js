(function() {
  // Flag to track if an alert has already been shown


//		let alertCount = 0; // Initialize alert count
		let colors = ['#FF6347', '#FFD700', '#4DBA67', '#4682B4', '#FF69B4', '#20B2AA', '#FF4500', '#6A5ACD', '#D2691E', '#40E0D0']; // Declare colors array globally
		const basePosition = Math.floor(Math.random() * (450 - 150 + 1)) + 150;
		const rightPosition = Math.floor(Math.random() * (350 - 50 + 1)) + 50;

		let markSuburbH = false;
		let markSameClient = false;
		let gCourt = false;
		let gPolice = false;
		let isMention = false;
		let alertCount = 0;
		let alertShown = false;
		let alertShownReplacement = 'false';
		let keywordsToCheck = [];

		let INT_number = "" ;
		let keywordsToCheckNesb = [];
		let keywordsToCheckSuburb = "";
		
		let baseGUrl = '';

		let keywordsToCheckVendor = ['Name or vendor no. of requested interpreter'];
		let keywordsToCheckCancelled = ['Cancelled within 1 day','Cancelled within 2 days','Cancelled within 3 days','Cancelled within 4 days','Cancelled within 5 days'];

		let enableClient = false;
		let enableSuburb = false;
		let enableNesb = false;


	  
	  
	  async function saveAsettings(name, color) {
		try {
			await browser.storage.local.set({ [name]: color });
			//console.log("Password saved successfully.");
			//var texts = name + " " + color;
		//	alert(texts);
		} catch (error) {
			console.error("Error saving the password:", error);
		}
	}
	  
	 
	 async function getStatus(name) {
		try {
			const statusE = await browser.storage.local.get(name);
			
			// Check if the value exists
			if (statusE[name] !== undefined) {
				return statusE[name]; // Return the existing value for the specific key
			} else {
				console.warn(`Value for "${name}" is not present. Setting default value to true.`);
				await browser.storage.local.set({ [name]: true }); // Save default value as true
				return true; // Return the default value
			}
		} catch (error) {
			console.error(`Error retrieving status for "${name}":`, error);
			return true; // Return default value as true in case of error
		}
	}
	 
	  
	  async function getAsettings(){
	//	  browser.storage.local.get(['highlightColor', 'backgroundColor']).then((result) => {
	//		  const highlightColor = result.highlightColor || '#FF4500'; // Default value if not set
//			  const backgroundColor = result.backgroundColor || '#FFFFE0'; // Default value if not set

//			  });

		const result = await browser.storage.local.get([
				'enableNesb', 'cNesb', 'cNesbBG',
				'enableSuburb', 'cSuburb', 'cSuburbBG',
				'enableClient', 'cClient', 'cClientBG'
			]);


	//	const cNesb = await browser.storage.local.get("cNesb");
	//	const cNesbBG = await browser.storage.local.get("cNesbBG");		


		
		
		

		enableNesb = result.enableNesb;
		enableSuburb = result.enableSuburb;
		enableClient = result.enableClient;
		
		if (enableNesb === undefined){
		//	alert();
			
			enableNesb = true;
			enableSuburb = true;
			enableClient = true;
			
			await browser.storage.local.set({
				enableNesb: true
			});
			
			await browser.storage.local.set({
				enableSuburb: true
			});

			await browser.storage.local.set({
				enableClient: true
			});

			
		}
		
		const cNesb = result.cNesb;
		const cNesbBG = result.cNesbBG;
		
		const cSuburb = result.cSuburb;
		const cSuburbBG = result.cSuburbBG;

		const cClient = result.cClient;
		const cClientBG = result.cClientBG;


//		if (cNesb.cNesb === undefined) {
		if (cNesb === undefined) {
			
		//	alert("You can now pick custom colors from CRC Assistance Settings");
			saveAsettings("cNesb","#477C9A");
			saveAsettings("cNesbBG","#FFFFFF");			


		//	saveAsettings("enableNesb","true");		
		//	saveAsettings("enableSuburb","true");		
		//	saveAsettings("enableClient","true");					
			
			const highlightColor = "#477C9A";
			const backgroundColor = "#FFFFFF";
			if (window.location.href.includes("showOL")) {
		//	alert(window.location.href);
			const style = document.createElement('style');
			  style.textContent = `
				.markNesb {
				  background-color: ${backgroundColor}}; 
				  color: ${highlightColor}; 
				}
				
			  `;
			  document.head.appendChild(style);
			}
					

		}  else {
			
			//alert(cNesb);
			//#477C9A
			if (cNesb === '#477C9A') {
				//alert();
				saveAsettings("cNesb","#FF0000");
				cNesb = "#FF0000";
			}
			
			const highlightColor = cNesb;
			const backgroundColor = cNesbBG;
			if (window.location.href.includes("showOL")) {
		//	alert(window.location.href);
			const style = document.createElement('style');
			  style.textContent = `
				.markNesb {
				  background-color: ${backgroundColor}; 
				  color: ${highlightColor}; 
				}
				
			  `;
			  document.head.appendChild(style);
			}	
			
		}
		
		
			if (cSuburb === undefined) {

				saveAsettings("cSuburb","#000000");
				saveAsettings("cSuburbBG","#D3EFBD");			
				
				const highlightColor = "#000000";
				const backgroundColor = "#D3EFBD";
				if (window.location.href.includes("showOL")) {
			//	alert(window.location.href);
				const style = document.createElement('style');
				  style.textContent = `
					.markSuburb {
					  background-color: ${backgroundColor}}; 
					  color: ${highlightColor}; 
					}
					
				  `;
				  document.head.appendChild(style);
				}
					

			}  else {
				
				const highlightColor = cSuburb;
				const backgroundColor = cSuburbBG;
				if (window.location.href.includes("showOL")) {
			//	alert(window.location.href);
				const style = document.createElement('style');
				  style.textContent = `
					.markSuburb {
					  background-color: ${backgroundColor}; 
					  color: ${highlightColor}; 
					}
					
				  `;
				  document.head.appendChild(style);
				}	
				
			}
	

			
				if (cClient === undefined) {

					saveAsettings("cClient","#CC0099");
					saveAsettings("cClientBG","#FFFFFF");			
					
					const highlightColor = "#CC0099";
					const backgroundColor = "#FFFFFF";
					if (window.location.href.includes("showOL")) {
				//	alert(window.location.href);
					const style = document.createElement('style');
					  style.textContent = `
						.markClient {
						  background-color: ${backgroundColor}}; 
						  color: ${highlightColor}; 
						}
						
					  `;
					  document.head.appendChild(style);
					}
						

				}  else {
					
					const highlightColor = cClient;
					const backgroundColor = cClientBG;
					if (window.location.href.includes("showOL")) {
				//	alert(window.location.href);
					const style = document.createElement('style');
					  style.textContent = `
						.markClient {
						  background-color: ${backgroundColor}; 
						  color: ${highlightColor}; 
						}
						
					  `;
					  document.head.appendChild(style);
					}	
					
				}
		
		
	  
	  }
	  
	  
//	  alert();
	  async function savePassword(password) {
		try {
			await browser.storage.local.set({ pwdn2: password });
			console.log("Password saved successfully.");
			alert('Password saved');
		} catch (error) {
			console.error("Error saving the password:", error);
		}
	}

 
	// Function to retrieve a password
	async function getPassword() {
			try {
				const data = await browser.storage.local.get("pwdn2");
			//	alert(data.pwdn2);
				  if (data.pwdn2 === undefined) {
					  
					let randomNumber = Math.floor(Math.random() * 900) + 100; 
					let correctAnswer = randomNumber * 3 + 9;
					
					let userInput = prompt(`What is the code for ${randomNumber} ?`);
					userInput = parseInt(userInput);

					
			//		let userInput = prompt("Please enter security code");
			//		let tInput = atob("MTMwMDY1MTUwMQ==");
					
//						if (userInput === tInput){
						if (correctAnswer === userInput){							
							
//							savePassword(tInput);						
							savePassword(userInput);													
						}
					}else{
						
//						if (data.pwdn2 !== atob("MTMwMDY1MTUwMQ==")) {
					//	if (data.pwdn2 !== atob("MTMwMDY1MTUwMQ==")) {							
							
	//						document.body = '';
					//		window.location.href = 'https://www.crclanguagelink.com.au/';
					//	}else{
							//alert();	
					//	}
					}
				
			
				//console.log("Retrieved password:", data.pwdn2);
				//alert(data.pwdn);
			} catch (error) {
				console.error("Error retrieving the password:", error);
			}
		}

	// Example usage
//	savePassword("your_password_here"); // Call this function to save a password



	getPassword(); // Call this function to retrieve a password
	//alert();
	getAsettings();
//*/
//
	function RandomColors() {

			const contrastingColors = [
			"#FF4500", // orange red
			"#FF6347", // tomato
			"#DC143C", // crimson
			"#FF69B4", // hot pink
			"#FF1493", // deep pink
			"#FF6F61", // salmon
			"#FF8C00", // dark orange
			"#FF7F50", // coral
			"#FF5722", // persimmon
			"#FFD700", // gold (darker shade)
			"#B22222", // firebrick
			"#D2691E", // chocolate
			"#CD5C5C", // indian red
			"#FF4500", // orangered
			"#FF1493", // medium pink
			"#A52A2A", // brown
			"#DAA520", // goldenrod
			"#FF4500", // orange red
			"#FF6347"  // tomato
			];


		const randomColor = contrastingColors[Math.floor(Math.random() * contrastingColors.length)];
		const highlightColor = '';
	
			const style = document.createElement('style');
			  style.textContent = `
				.markRandom {
				  background-color: ${randomColor}}; 
				  color: white; 
				}
				
			  `;
			  document.head.appendChild(style);
	}
	

	function activateColors() {
		
		if (window.location.href.includes("showOL")) {
		//	alert(window.location.href);
			const style = document.createElement('style');
			  style.textContent = `
				.markOrangeRed {
				  background-color: ${highlightColor}; 
				  color: white; 
				}
				body {
				  background-color: ${backgroundColor};
				}
			  `;
			  document.head.appendChild(style);
		}
		
	}



	//activateColors();

		 

function escapeRegExp(string) {
    return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}
  // Function to find an element using XPath in the given document (main document or iframe)
  function getElementByXPath(xpath, doc = document) {
    return doc.evaluate(xpath, doc, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
  }
 
  // Function to check the entire document (or iframe) for specific keywords and highlight them
  function checkForKeywords(keywords, doc = document) {
    // Target the body of the document or iframe
	
	
    const targetElement = doc.body;
    highlightKeywordInElement(targetElement, keywords);

   
	
  }

  function highlightElement(element) {
    if (element) {
      element.style.backgroundColor = 'cyan'; // Apply highlighting style
    }
  }
  
  function multiattach() {
	attach = 'False';

	if (window.location.href.includes('custom=Attachments')) {
		attach = 'True';
	}

	if (
		window.location.href.includes('crclanguagelink.com.au/index.php') ||
		window.location.href.includes('www.crclanguagelink.com.au/index.php?app_form_cd=SYS033&_template=plain')
	) {
		attachmentPath = '/html/body/div[2]/div/form/div/h1';
		isAttach = getElementByXPath(attachmentPath);

		if (isAttach && isAttach.textContent.includes('Attachments')) {
			attach = 'True';
		}
	}

	if (attach == 'True') {
		const fileInput = document.querySelector('input[name="path_file"]');
		const form = document.getElementById("SYS033");

		if (!fileInput || !form) return;

		// ✅ Extract item_id from URL
		const urlMatch = window.location.href.match(/item_id=(\d{7})/);
		const urlItemId = urlMatch ? urlMatch[1] : null;

		fileInput.setAttribute("multiple", true);

		// Create drag & drop UI
		const dropBox = document.createElement("div");
		dropBox.id = "dropZone";
		dropBox.style.cssText = `
			border: 2px dashed #ccc;
			padding: 20px;
			margin-top: 10px;
			text-align: center;
			color: #666;
			background: #f9f9f9;
			min-height: 120px;
		`;
		dropBox.innerText = "Drag and drop files here to attach automatically";
		fileInput.parentElement.appendChild(dropBox);

		// Add feedback section
		const feedbackBox = document.createElement("div");
		feedbackBox.id = "dropFeedback";
		feedbackBox.style.marginTop = "10px";
		dropBox.parentElement.appendChild(feedbackBox);

		// Upload handler function with confirmation
		async function handleUpload(files) {
			feedbackBox.innerHTML = "";

			for (let i = 0; i < files.length; i++) {
				const file = files[i];

				// ✅ Check for item ID mismatch first
				let proceed = true;
				if (urlItemId) {
					const nameMatch = file.name.match(/(\d{7})/);
					if (nameMatch && nameMatch[1] !== urlItemId) {
						proceed = false;

						const warn = document.createElement("div");
						warn.innerHTML = `⚠️ <strong>Item ID mismatch!</strong><br>
						File has <b>${nameMatch[1]}</b>, but URL has <b>${urlItemId}</b>`;
						warn.style.color = "white";
						warn.style.backgroundColor = "red";
						warn.style.padding = "10px";
						warn.style.marginTop = "10px";
						warn.style.fontWeight = "bold";
						warn.style.boxShadow = "0 0 10px red";
						warn.style.border = "2px solid darkred";
						warn.style.borderRadius = "6px";

						const btnContinue = document.createElement("button");
						btnContinue.textContent = "Continue Upload";
						btnContinue.style.marginRight = "10px";

						const btnCancel = document.createElement("button");
						btnCancel.textContent = "Cancel";

						const btnBox = document.createElement("div");
						btnBox.style.marginTop = "10px";
						btnBox.appendChild(btnContinue);
						btnBox.appendChild(btnCancel);

						feedbackBox.appendChild(warn);
						feedbackBox.appendChild(btnBox);

						await new Promise((resolve) => {
							btnContinue.onclick = () => {
								proceed = true;
								resolve();
							};
							btnCancel.onclick = () => {
								proceed = false;
								resolve();
							};
						});

						// Cleanup UI
						warn.remove();
						btnBox.remove();
					}
				}

				if (!proceed) {
					const skipMsg = document.createElement("div");
					skipMsg.textContent = `⏭️ Skipped: ${file.name}`;
					skipMsg.style.color = "gray";
					feedbackBox.appendChild(skipMsg);
					continue;
				}

				// ✅ Proceed to upload
				const fd = new FormData(form);
				fd.set("path_file", file);
				fd.set("page_action", "attach");

				const response = await fetch(form.action, {
					method: "POST",
					body: fd
				});

				const msg = document.createElement("div");
				msg.textContent = `${response.ok ? "✅ Uploaded: " : "❌ Failed: "}${file.name}`;
				msg.style.color = response.ok ? "green" : "red";
				feedbackBox.appendChild(msg);
			}

			setTimeout(() => location.reload(), 1000);
		}

		// Input file change
		fileInput.addEventListener("change", async (e) => {
			const files = e.target.files;
			if (files.length > 0) await handleUpload(files);
		});

		// Drag & drop
		dropBox.addEventListener("dragover", (e) => {
			e.preventDefault();
			dropBox.style.borderColor = "#000";
		});
		dropBox.addEventListener("dragleave", () => {
			dropBox.style.borderColor = "#ccc";
		});
		dropBox.addEventListener("drop", async (e) => {
			e.preventDefault();
			dropBox.style.borderColor = "#ccc";
			const files = e.dataTransfer.files;
			if (files.length > 0) await handleUpload(files);
		});
		}
	}

    function highlightVendorDates() {
  
			  // Get the value from the element
			let htmlk = document.documentElement.innerHTML;
			const dateValueRego = document.querySelector('#LS_LSRProfile_e_lsRes_e_lsr_crego_exp_tm_dt').value;

			// Parse the date value (assuming it's in dd/mm/yyyy format)
			const [day, month, year] = dateValueRego.split('/');  // Split into day, month, year
			const parsedDateRego = new Date(`${year}-${month}-${day}`);  // Convert to Date object (yyyy-mm-dd format)

			// Get today's date
			const today = new Date();
			today.setHours(0, 0, 0, 0);  // Set to start of the day for comparison

			// Compare the dates
			if (parsedDateRego < today) {
				//alert(today);
				
				
				
				let resultAsStringRep = '<span class="markYellow">' + 'Rego expiry date' +  "</span>" ;
				htmlk = htmlk.replace('Rego expiry date', resultAsStringRep);
				
				
			} else {
				//alert(parsedDate);
			}

			
			const dateValuePolicy = document.querySelector('#LS_LSRProfile_e_lsRes_e_lsr_cins_exp_tm_dt').value;

			// Parse the date value (assuming it's in dd/mm/yyyy format)
			const [day2, month2, year2] = dateValuePolicy.split('/');  // Split into day, month, year
			const parsedDatePolicy = new Date(`${year2}-${month2}-${day2}`);  // Convert to Date object (yyyy-mm-dd format)
		//	alert(dateValuePolicy);
			if (parsedDatePolicy < today) {
//				alert(today);
				
				let resultAsStringRep = '<span class="markYellow">' + 'Policy expiry date' +  "</span>" ;
				htmlk = htmlk.replace('Policy expiry date', resultAsStringRep);
				
				
			} else {
		//		alert(parsedDatePolicy);
			}

			
			const dateValueDL = document.querySelector('#LS_LSRProfile_e_lsRes_e_lsr_drvlic_exp_tm_dt').value;

			// Parse the date value (assuming it's in dd/mm/yyyy format)
			const [day3, month3, year3] = dateValueDL.split('/');  // Split into day, month, year
			const parsedDateDL = new Date(`${year3}-${month3}-${day3}`);  // Convert to Date object (yyyy-mm-dd format)

			if (parsedDateDL < today) {
		//		alert(today);
				
				let resultAsStringRep = '<span class="markYellow">' + "Driver's Licence Expiry date" +  "</span>" ;
				htmlk = htmlk.replace("Driver's Licence Expiry date", resultAsStringRep);
				
				
			} else {
		//		alert(parsedDateDL);
			}
			
			document.documentElement.innerHTML = htmlk;
	}
	
	
  function fixNotes(){
	   
		if (window.location.href.toLowerCase().includes("app_form_cd=fcls1191") && window.location.href.toLowerCase().includes("_id=")) {
			let htmlk = document.documentElement.innerHTML;
			
			  
			//	const regexN = /class="text_srch_disp_label_none">(\d{2}\/\d{2}\/\d{4}) (\d{2}:\d{2})/g;
				const regexN = /class="text_srch_disp_label_none">(\d{2}\/\d{2}\/\d{4}) (\d{2}:\d{2})/g;

				// Get today's date in the same format (dd/mm/yyyy)
				const today = new Date();
				const todayString = ("0" + today.getDate()).slice(-2) + "/" + ("0" + (today.getMonth() + 1)).slice(-2) + "/" + today.getFullYear();
			//	const todayString = "16/10/2024";
			//	const todayString = "16/10/2024";
			//	alert(todayString);
				
				// Function to check if a time is within the last 60 minutes
				function isWithinLast60Minutes(timeString) {
					const [hours, minutes] = timeString.split(':').map(Number);
					const time = new Date();
					time.setHours(hours, minutes, 0, 0);

					const diff = (today.getTime() - time.getTime()) / (1000 * 60); // Difference in minutes
					return diff <= 180 && diff >= 0;
				}



				function isMoreThan5DaysOld(dateString) {
					const [day, month, year] = dateString.split('/').map(Number);
					const date = new Date(year, month - 1, day);

					const diffInDays = (today.getTime() - date.getTime()) / (1000 * 60 * 60 * 24); // Difference in days
					return diffInDays > 5;
				}

				// Function to check if the previous two days were Saturday and Sunday
				function previousTwoDaysWereWeekend() {
					const yesterday = new Date(today);
					const dayBeforeYesterday = new Date(today);
					
					// Adjust dates to get yesterday and day before yesterday
					yesterday.setDate(today.getDate() - 1);
					dayBeforeYesterday.setDate(today.getDate() - 2);

					const isYesterdaySaturday = yesterday.getDay() === 6;
					const isDayBeforeSunday = dayBeforeYesterday.getDay() === 0;

					return isYesterdaySaturday && isDayBeforeSunday;
				}
				
				
				// Match all instances of the date and time pattern
				let match;
				let highlightTodayFound = false; // Flag to track if today's match has been found				 
				while ((match = regexN.exec(htmlk)) !== null) {
				
					const date = match[1];
					const time = match[2];

					// Check if the date matches today and time is within the last 60 minutes
					if (date === todayString && isWithinLast60Minutes(time) && !highlightTodayFound) {
					    highlightTodayFound = true; // Set the flag to true
						const highlight = `class="markNotesRecent">${date} ${time}`;
						htmlk = htmlk.replace(match[0], highlight);
					}
					
					
					//if (!highlightTodayFound && isMoreThan5DaysOld(date) && !previousTwoDaysWereWeekend()) {

					if (!highlightTodayFound && isMoreThan5DaysOld(date)) {
						highlightTodayFound = true;
					//	alert();
						// Highlight the matched part in HTML for dates older than 3 days (unless previous days were weekend)
						const highlight = `class="markNotesOld">${date} ${time}`;
						htmlk = htmlk.replace(match[0], highlight);

					}
					highlightTodayFound = true
					
					
				}


				// Apply the modified HTML back to the document
				document.documentElement.innerHTML = htmlk;

			
		}
  }
  
  
  function fixPhone(){
	  
	  //alert();
	  
	  
	  
	
	 
	  
	  if (window.location.href.toLowerCase().includes("sys003.htm?app_form_cd=fcls1110&page_action=view&_template=default_no_menu&item_id=")) { // cleintCancel
	 
		convertTelephoneThree();
	}
	
	  if (window.location.href.toLowerCase().includes("app_form_cd=fcls1118&prcs_defn_cd=&_template=default&_al_action_click=1&mode=edit&state_cd=&app_cd=&item_id=")) {
	 
		convertTelephoneFour();
	}

	  if (window.location.href.toLowerCase().includes("app_form_cd=fcls1028&prcs_defn_cd=&_template=default&_al_action_click=1&mode=edit&state_cd=&app_cd=&item_id=")) { // selfcancel
		//alert();
		convertTelephoneFive();
	}


	
	
	if (window.location.href.includes("page_action=edit&_al_action_click=")){
		
		convertTelephone();
		ExtractHeader(xpathToExtract);
	//	alert();
		//convertTelephoneTwo();
	}


  
	if (window.location.href.toLowerCase().includes("_template=default_no_menu&app_form_cd=fcls1110&tab_cd=LS_RES&page_action=view&item_id")){
		convertTelephoneTwo();
	}
	
	if (window.location.href.toLowerCase().includes("app_form_cd=fcls1110&page_action=view&_template=default_no_menu&tab_cd=LS_RES&item_id=")){
		convertTelephoneTwo();
	}
  }
  
  

  // Function to monitor both the main document and iframe for keywords
  function monitorMainDocumentAndIframe(keywords, iframeId, xpathForIframeElement, inputXPath, labelXPath, additionalInputXPath, additionalLabelXPath) {	  
  
  
  
  
	
 	
  
    // Check for keywords in the main document
    checkForKeywords(keywords);

	headPath = '//*[@id="sys_desc"]';
	  
	 const headerType = getElementByXPath(headPath, document);
	// if (headerType && headerType.textContent.includes(', INT')){
						//alert("TRN");
	//
	 //}


    // Now check inside the iframe
    const iframe = document.getElementById(iframeId);

	urlCheck1 = 'app_form_cd=fcls1160&prcs_defn_cd=&_template=default&_al_action_click=1&mode=edit&state_cd=&app_cd=&item_id';

	
	if (headerType && headerType.textContent.includes('Manual Allocation')  && headerType.textContent.includes(', TRN') && window.location.href.toLowerCase().includes(urlCheck1) ){
//	if (headerType && headerType.textContent.includes('Manual Allocation')  && headerType.textContent.includes(', TRN')){

		
						const iframe = document.querySelector('iframe');
						
					//*	iframe.onload = () => {
					//	iframe.addEventListener('load', () => {
							const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
							const dateXpath = '//*[@id="LS_BookingTranslation_e_trnBD_e_rtn_ls_date_tm_dt"]';
							const inputElement = iframeDoc.evaluate(dateXpath, iframeDoc, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
							
						//	const inputElement = getElementByXPath(inputXPath, iframeDoc);
						//	if (inputElement && inputElement.value.trim() !== '') {
							
							if (inputElement) {
								//alert('658');
							//		alert();
									const dateText = inputElement.value.trim();
									const [day, month, year] = dateText.split('/').map(Number);
									const parsedDate = new Date(year, month - 1, day); // month is 0-based

									const today = new Date();
									// Set today's time to 00:00:00 so we compare dates only
									today.setHours(0, 0, 0, 0);

									if (parsedDate < today) {
										console.log("The date is older than today.");
										//alert("Older date found!");
										showNotificationBootstrapNotify("Please check and change date of return from translator");
										showNotificationBootstrapNotify("Please check and change date of return to client");
										hPath = '/html/body/div[2]/div/form/div/fieldset[4]/div[2]/div/label';
										elHpath = getElementByXPath(hPath,iframeDoc );
										//alert(elHpath);
										highlightElement(elHpath);
										hPath2 = '/html/body/div[2]/div/form/div/fieldset[4]/div[4]/div/label';
										elHpath2 = getElementByXPath(hPath2,iframeDoc );
										//alert(elHpath);
										highlightElement(elHpath2)
									//	elHpath2 = getElementByXPath(hPath2);
									//	highlightElement(elHpath2);
									}							

								
							}
							
						}
				//	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	//showNotificationBootstrapNotify("Extra popup");
	iRBlink = "https://www.crclanguagelink.com.au/index.php?app_form_cd=fcls1003&prcs_defn_cd=&_template=default&_al_action_click=1&mode=edit&state_cd=&app_cd=&item_id=";
    
	 
	
	if (headerType && headerType.textContent.includes(', INT') && iframe &&  !window.location.href.toLowerCase().includes(iRBlink) && !window.location.href.toLowerCase().includes('fcls1034')) {

	
 		
		
		const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;

		//alert('iframe loaded');
		
        // Check first input element
        const inputElement = getElementByXPath(inputXPath, iframeDoc);
        if (inputElement && inputElement.value.trim() !== '') {
          const labelElement = getElementByXPath(labelXPath, iframeDoc);
          highlightElement(labelElement); // Highlight the first label element
		   showNotificationBootstrapNotify('Custom language request');
        }
		
		
		

        // Check additional input element
        const additionalInputElement = getElementByXPath(additionalInputXPath, iframeDoc);
        if (additionalInputElement && additionalInputElement.value.trim() !== '') {
			
			
          const additionalLabelElement = getElementByXPath(additionalLabelXPath, iframeDoc);
          highlightElement(additionalLabelElement); // Highlight the additional label element
		  
		  
	
	//	headPath = '//*[@id="sys_desc"]';
		  
	//	  const headerType = getElementByXPath(headPath, document);
	//	alert(fieldnotes2);
							//htmlkk = headerType.innerHTML;
	//			 if (headerType && headerType.textContent.includes(', INT')){
						//alert("TRN");
	//
	//			 }
			
			showNotificationBootstrapNotify('Specific Gender');	  
		  
        }
		
		
		additionalInputElement2Path = '/html/body/div[2]/div/form/div/fieldset[3]/div[6]/div/textarea'; // description tab
		
		const additionalInputElement2 = getElementByXPath(additionalInputElement2Path, iframeDoc);
	//	alert(additionalInputElement2.value);
        if (additionalInputElement2 && additionalInputElement2.value.trim() !== '') {
			
			
          if (additionalInputElement2.value.toLowerCase().includes("certified")) {
           showNotificationBootstrapNotify('Level 3 Interpreter');
          }  
        }
		
		additionalInputElement3Path = '/html/body/div[2]/div/form/div/fieldset[4]/div[2]/div/textarea'; // description tab
		
		
		const additionalInputElement3 = getElementByXPath(additionalInputElement3Path, iframeDoc);
	//	alert(additionalInputElement2.value);
        if (additionalInputElement3 && additionalInputElement3.value.trim() !== '') {
			showNotificationBootstrapNotify('Check for Special Requirement');
			
        //  if (additionalInputElement3.value.toLowerCase().includes("certified")) {
         //  showNotificationBootstrapNotify('Level 3 Interpreter ');
         // }  
        }
		
		
		additionalInputElement4Path = '/html/body/div[2]/div/form/div/fieldset[3]/div[6]/div[1]/input[2]'; // type of matter
		
		const additionalInputElement4 = getElementByXPath(additionalInputElement4Path, iframeDoc);
	//	alert(additionalInputElement2.value);
        if (additionalInputElement4 && additionalInputElement4.value.trim() !== '') {
			//alert(additionalInputElement4.value);
			 if (additionalInputElement4.value.toLowerCase().includes("payable")) {
				showNotificationBootstrapNotify('Fee Paybale');
				 
				pathXDesc = '/html/body/div[2]/div/form/div/fieldset[3]/div[6]/div[1]/label';
				 
				const additionalLabelElementD = getElementByXPath(pathXDesc, iframeDoc);
				highlightElement(additionalLabelElementD); // Highlight the additional label element
			 }
		//	showNotificationBootstrapNotify('Check for Special Requirement');
			
        //  if (additionalInputElement3.value.toLowerCase().includes("certified")) {
         //  showNotificationBootstrapNotify('Level 3 Interpreter ');
         // }  
        }
		
		
		 
	
	
	} else {
     // alert('Iframe not found');
    }
  }

/*/
function showNotificationBootstrapNotify(message) {
    const alertDiv = document.createElement('div');
    alertDiv.className = 'custom-alert';
    alertDiv.role = 'alert';

    alertDiv.innerHTML = `
        <strong>Notice:</strong> ${message}
        <button type="button" class="close-button" aria-label="Close">
            &times;
        </button>
    `;

    // Append the alert to the body
    document.body.appendChild(alertDiv);

    // Add event listener to the close button
    const closeButton = alertDiv.querySelector('.close-button');
    closeButton.addEventListener('click', () => {
        alertDiv.classList.add('hide');

        // Remove the alert from DOM after transition
        setTimeout(() => {
            alertDiv.remove();
        }, 2500);
    });

    // Automatically close the alert after 5 seconds
    setTimeout(() => {
        alertDiv.classList.add('hide');
        setTimeout(() => {
            alertDiv.remove();  // Remove the alert from DOM
        }, 2500);
    }, 5000);
}
*/

function showNotificationBootstrapNotifyd(message) {
    // Create an alert container if it doesn't exist
    let alertContainer = document.getElementById('alert-container');
    if (!alertContainer) {
        alertContainer = document.createElement('div');
        alertContainer.id = 'alert-container';
        alertContainer.style.position = 'fixed'; // Change this to fixed or absolute based on your layout
        alertContainer.style.top = '20px'; // Adjust as needed
        alertContainer.style.right = '20px'; // Right alignment
        alertContainer.style.zIndex = 9999; // Ensure it's on top of other elements
        document.body.appendChild(alertContainer);
    }

    const alertDiv = document.createElement('div');
    alertDiv.className = 'custom-alert';
    alertDiv.role = 'alert';

    alertDiv.innerHTML = `
        <strong>Tips:</strong> ${message}
        <button type="button" class="close-button" aria-label="Close">
            &times;
        </button>
    `;

    // Append the alert to the container
    alertContainer.appendChild(alertDiv);

    // Add event listener to the close button
    const closeButton = alertDiv.querySelector('.close-button');
    closeButton.addEventListener('click', () => {
        alertDiv.classList.add('hide');

        // Remove the alert from DOM after transition
        setTimeout(() => {
            alertDiv.remove();
        }, 5000); // Duration of the fade-out transition.
    });

    // Automatically close the alert after 5 seconds (5000 ms)
    setTimeout(() => {
        alertDiv.classList.add('hide');
        setTimeout(() => {
            alertDiv.remove(); // Remove the alert from DOM
        }, 5000);
    }, 5000);
}




	function showNotificationBootstrapNotify(message) {
		
		let tOut;
			//if (window.location.href.toLowerCase().includes("&ol_order_nr=")) {
			if (window.location.href.toLowerCase().includes("&ol_order_nr=") || window.location.href.toLowerCase().includes('app_form_cd=fcls1160')) {

				tOut = 500;
			} else {
				tOut = 2000;
			}

		// Delay the creation of the alert by 3 seconds
		setTimeout(() => {
			const alertDiv = document.createElement('div');
			alertDiv.classList.add('custom-alert');

			// Array of colors
			const colors = [
				'#4DBA67', '#FF6F61', '#6A5ACD', '#FF69B4', '#40E0D0', '#4682B4', '#D2691E', 
				'#20B2AA', '#FF4500', '#8A2BE2', '#DC143C', '#9932CC', '#B22222', '#008080', 
				'#800080', '#CD5C5C', '#4169E1', '#FF6347', '#7B68EE', '#8B4513'
			];

			// Styles
			const styles = ['style-1'];

			// Randomly select a color and style
			const randomColor = colors[Math.floor(Math.random() * colors.length)];
			const randomStyle = styles[Math.floor(Math.random() * styles.length)];

			// Set the content, random style, and random color of the alert
			alertDiv.innerText = message;
			alertDiv.style.backgroundColor = randomColor;
			alertDiv.classList.add(randomStyle);

			// Set the position of the alert based on alertCount
			const offset = alertCount * 70; // Offset each subsequent alert by 70px
			alertDiv.style.top = `${basePosition + alertCount * 60}px`;
			alertDiv.style.right = `${rightPosition}px`; // Fixed right position

			// Append the alert to the body
			document.body.appendChild(alertDiv);

			// Set timeout duration based on URL condition
			
			// Automatically remove the alert after the specified timeout
			setTimeout(() => {
				alertDiv.style.opacity = '0'; // Fade out the alert
				setTimeout(() => alertDiv.remove(), tOut); // Remove the element after fade-out
			}, 7000);

			// Increment alert count for the next alert
			alertCount++;
		}, tOut); // Delay of 3 seconds
	}


/////////////////////////// marker


function showNotificationBootstrapNotifyN(message) {
    if (colors.length === 0) {
        // If all colors have been used, reset the colors array
        colors = ['#FF6347', '#FFD700', '#4DBA67', '#4682B4', '#FF69B4', '#20B2AA', '#FF4500', '#6A5ACD', '#D2691E', '#40E0D0'];
    }
    
    // Create a new div for the alert
    const alertDiv = document.createElement('div');
    alertDiv.classList.add('custom-alert');
	
    // Select a random color from the remaining colors
    const randomIndex = Math.floor(Math.random() * colors.length);
    const randomColor = colors[randomIndex];

    // Remove the selected color from the array
    colors.splice(randomIndex, 1);
    
    // Set the content and background color of the alert
    alertDiv.innerText = message;
    alertDiv.style.backgroundColor = randomColor;
	
    // Adjust the top position based on how many alerts have been shown
    alertDiv.style.top = `${250 + alertCount * 60}px`; // Move 60px down for each new alert
    
    
    // Append the alert to the body
    document.body.appendChild(alertDiv);
//    setTimeout(() => alertDiv.classList.add('show'), 10); // Add a small delay to ensure the CSS transition works
    // Automatically remove the alert after 5 seconds
    setTimeout(() => {
        alertDiv.style.opacity = '0'; // Fade out the alert
        setTimeout(() => alertDiv.remove(), 1000); // Remove the element after fade-out
    }, 5000);
    
    // Increment alert count for the next alert
    alertCount++;
}


  
function showNotificationBootstrapNotifyxxx(message) {
    // Create a new div for the alert
    const alertDiv = document.createElement('div');
    alertDiv.classList.add('custom-alert');
	
	 const colors = ['#FF6347', '#FFD700', '#4DBA67', '#4682B4', '#FF69B4', '#20B2AA', '#FF4500', '#6A5ACD', '#D2691E', '#40E0D0'];
     const randomColor = colors[Math.floor(Math.random() * colors.length)];
    // Set the content of the alert
    alertDiv.innerText = message;
    alertDiv.style.backgroundColor = randomColor;
	
    // Adjust the top position based on how many alerts have been shown
    alertDiv.style.top = `${250 + alertCount * 60}px`; // Move 60px down for each new alert
    
    // Append the alert to the body
    document.body.appendChild(alertDiv);
    
    // Automatically remove the alert after 3 seconds
    setTimeout(() => {
        alertDiv.style.opacity = '0'; // Fade out the alert
        setTimeout(() => alertDiv.remove(), 1000); // Remove the element after fade-out
    }, 5000);
    
    // Increment alert count for the next alert
    alertCount++;
}

  // Function to convert telephone number to hyperlik
function convertTelephone(){
	const xpathPhone = '/html/body/div[2]/div[4]/form/div/fieldset[1]/div[3]/div[2]';	
	
						
		const fieldnotes = getElementByXPath(xpathPhone, document);
	//	alert(fieldnotes);
		if (fieldnotes) {
			htmlk = fieldnotes.innerHTML;
		//	alert(htmlk);
			
			const regexN = /value="(\d+)"/; 
			var pInfo = htmlk.match(regexN); 
			
			if (pInfo && pInfo[1]) {
				textA =	htmlk + '<br><a href="tel:' + pInfo[1] + '"><span class="markClientX">Call Direct :' + pInfo[1] + '</span>' + '</a>';
				fieldnotes.innerHTML = textA;
				//alert(textA);
				//htmlk = htmlk.replace(regexN, resultAsStringRep);

			}	
		}
		
		const xpathPhone2 = '/html/body/div[2]/div[4]/form/div/fieldset[2]/div[3]/div[2]';	
	
						
		const fieldnotes2 = getElementByXPath(xpathPhone2, document);
	//	alert(fieldnotes2);
		if (fieldnotes2) {
			htmlk = fieldnotes2.innerHTML;
		//	alert(htmlk);
			
			const regexN = /value="(\d+)"/; 
			var pInfo = htmlk.match(regexN); 
			
			if (pInfo && pInfo[1]) {
				textA =	htmlk + '<br><a href="tel:' + pInfo[1] + '"><span class="markClientX">Call Direct :' + pInfo[1] + '</span>' + '</a>';
				fieldnotes2.innerHTML = textA;
				//alert(textA);
				//htmlk = htmlk.replace(regexN, resultAsStringRep);

			}	
		}
		
		
		
}


 // Function to convert telephone number to hyperlik
function convertTelephoneFour(){
	//alert();
	const xpathPhone = '/html/body/div[2]/div[4]/form/div/fieldset[3]/div[4]';	
		const fieldnotes = getElementByXPath(xpathPhone, document);
	//	alert(fieldnotes);
		if (fieldnotes) {
			htmlk = fieldnotes.innerHTML;
		//	alert(htmlk);
			
			const regexN = /value="(\d+)"/; 
			var pInfo = htmlk.match(regexN); 
			
			if (pInfo && pInfo[1]) {
				textA =	htmlk + '<br><a href="tel:' + pInfo[1] + '"><span class="markClientX">Call Direct :' + pInfo[1] + '</span>' + '</a>';
				fieldnotes.innerHTML = textA;
				//alert(textA);
				//htmlk = htmlk.replace(regexN, resultAsStringRep);

			}	
		}
}



function convertTelephoneFive(){
	//alert();
	const xpathPhone = '/html/body/div[2]/div[4]/form/div/fieldset[2]/div[4]';	
		const fieldnotes = getElementByXPath(xpathPhone, document);
	//	alert(fieldnotes);
		if (fieldnotes) {
			htmlk = fieldnotes.innerHTML;
		//	alert(htmlk);
			
			const regexN = /value="(\d+)"/; 
			var pInfo = htmlk.match(regexN); 
			
			if (pInfo && pInfo[1]) {
				textA =	htmlk + '<br><a href="tel:' + pInfo[1] + '"><span class="markClientX">Call Direct :' + pInfo[1] + '</span>' + '</a>';
				fieldnotes.innerHTML = textA;
				//alert(textA);
				//htmlk = htmlk.replace(regexN, resultAsStringRep);

			}	
		}
}


 // Function to convert telephone number to hyperlik
function convertTelephoneThree(){
	//alert();
	const xpathPhone = '/html/body/div[2]/div[3]/form/div/fieldset[4]/div[2]/div[1]';	
		const fieldnotes = getElementByXPath(xpathPhone, document);
	//	alert(fieldnotes);
		if (fieldnotes) {
			htmlk = fieldnotes.innerHTML;
		//	alert(htmlk);
			
			const regexN = /value="(\d+)"/; 
			var pInfo = htmlk.match(regexN); 
			
			if (pInfo && pInfo[1]) {
				textA =	htmlk + '<br><a href="tel:' + pInfo[1] + '"><span class="markClientX">Call Direct :' + pInfo[1] + '</span>' + '</a>';
				fieldnotes.innerHTML = textA;
				//alert(textA);
				//htmlk = htmlk.replace(regexN, resultAsStringRep);

			}	
		}
}

function htmlEncode(str) {
    let div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
}

 // Function to convert telephone number to hyperlik
function convertTelephoneTwo(){
	//alert();
	const xpathPhone = '/html/body/div[2]/div[3]/form/div/fieldset[4]/div[2]/div[1]';	
		const fieldnotes = getElementByXPath(xpathPhone, document);
	//	alert(fieldnotes);
		if (fieldnotes) {
			htmlk = fieldnotes.innerHTML;
		//	alert(htmlk);
			
			const regexN = /value="(\d+)"/; 
			var pInfo = htmlk.match(regexN); 
			
			if (pInfo && pInfo[1]) {
				textA =	htmlk + '<br><a href="tel:' + pInfo[1] + '"><span class="markClientX">Call Direct :' + pInfo[1] + '</span>' + '</a>';
				fieldnotes.innerHTML = textA;
				//alert(textA);
				//htmlk = htmlk.replace(regexN, resultAsStringRep);

			}	
		}
}

  // Function to highlight the keyword in the text, including links
  function highlightKeywordInElement(element, keywords) {
 
	
	const xpath1 = '/html/body/div[2]/div[4]/form/div/fieldset[5]';
	const fieldset1 = getElementByXPath(xpath1, document);
	
	const xpath11 = '/html/body/div[2]/div[4]/form/div/fieldset[6]';
	const fieldset11 = getElementByXPath(xpath11, document);

	//alert(fieldset1.innerHTML);
	if (fieldset1) { // vendor / specific Interpreter  highlight
		//alert(fieldset.innerHTML);
		let htmlk = fieldset1.innerHTML;
		const regex = new RegExp(`\\b(${keywordsToCheckVendor.join('|')})\\b`, 'gi');

		htmlk = htmlk.replace(regex, `<span class="markVendor">$1</span>`); // Wrap the matched keyword in <span>
		
		fieldset1.innerHTML = htmlk;
	}

	if (fieldset11) { // vendor / specific Interpreter  highlight
		//alert(fieldset.innerHTML);
		let htmlk = fieldset11.innerHTML;
		const regex = new RegExp(`\\b(${keywordsToCheckVendor.join('|')})\\b`, 'gi');

		htmlk = htmlk.replace(regex, `<span class="markVendor">$1</span>`); // Wrap the matched keyword in <span>
		
		fieldset11.innerHTML = htmlk;
	}
	
	
	
 	if ((window.location.href.includes("showOL"))|(window.location.href.includes("ol_order_nr"))|(window.location.href.includes('&item_id='))) {
		
		
		//Change 1
		
		const xpathnotes = '/html/body/div[2]/div[3]/div[2]';	
		const fieldnotes = getElementByXPath(xpathnotes, document);
		if (fieldnotes) {
			htmlk = fieldnotes.innerHTML;
			const regexN = /(alt="Notes">[^>]+>)(\d+)/; // searching note number
			 var fInfo = htmlk.match(regexN); 
			 var p1 = fInfo[1];
			 var p2 = fInfo[2];

			 let resultAsString = p1 + p2.toString();
			 let resultAsStringRep = p1 + '<span class="markOrangeRed">' + p2.toString() + " NOTES"+ "</span>" ;
			
			 
			 
			  // Use replace() to replace the captured group (the number) with the desired string
			  if (p2) {
				htmlk = htmlk.replace(regexN, resultAsStringRep);
			  
				
				if (window.location.href.includes('&item_id=')){
					htmlk = htmlk.replace(/900,600/g, "1200,600");
					htmlk = htmlk.replace(/900,800/g, "1100,800");
				}
				fieldnotes.innerHTML = htmlk;
			  }
		}
		
		
		
		
		
		
		
		

		const xpath2 = '/html/body/div[2]/div[4]/form/div/fieldset[2]'; // Your provided XPath
		 
		const fieldset2 = getElementByXPath(xpath2, document);


			if (fieldset2) { // cancel alert
				//alert(fieldset.innerHTML);
				let htmlk = fieldset2.innerHTML;
			//	const kcll = fieldset.toLowerCase().includes("cancelled within 1 days");
			//	const kcll2 = fieldset.toLowerCase().includes("cancelled within 2 days");		// Normalize to lower case	
				const regex = new RegExp(`\\b(${keywordsToCheckCancelled.join('|')})\\b`, 'gi');

				htmlk = htmlk.replace(regex, `<span class="markVendor">$1</span>`); // Wrap the matched keyword in <span>
				fieldset2.innerHTML = htmlk;
				
				
				const kcll = htmlk.toLowerCase().includes("cancelled within 1 day");
				const kcll2 = htmlk.toLowerCase().includes("cancelled within 2 days");		// Normalize to lower case	
				const kcll3 = htmlk.toLowerCase().includes("cancelled within 3 days");
				const kcll4 = htmlk.toLowerCase().includes("cancelled within 4 days");
				const kcll5 = htmlk.toLowerCase().includes("cancelled within 5 days");
				//html = html.replace(regex, `<span class="mark">$1</span>`); // Wrap the matched keyword in <span>
				
				if (kcll||kcll2|kcll3|kcll4|kcll5) {
					if (alertShownReplacement === 'false') {
						alertShownReplacement = 'true';
						// Delay the first notification by 3 seconds (3000 ms)
						setTimeout(() => {
							showNotificationBootstrapNotify('Possible Replacement Offer');
							
						}, 500); // 3-second delay
					}
				}
				
				
			}
	}
	////
	////
	

	
	
	
	
	//if (osdb){
	//	alert('found');
	//}
	//alert(fieldset3.innerHTML);
	 if (window.location.href.includes("showOL")) {
			const xpath3 = '/html/body/div[2]/div[4]/form/div/fieldset[1]';
			const fieldset3 = getElementByXPath(xpath3, document);
		
		
		
		
			if (fieldset3) {  // for Suburb / client match / nesb
			//	alert(fieldset3.innerHTML);

				const osdb = fieldset3.innerHTML.toLowerCase().includes("other same day bookings");
				if (osdb){		 

						//	fieldset3.innerHTML = div.innerHTML; 
					
					let htmlk = fieldset3.innerHTML;
				//	alert(htmlk);
					
					let fmatches = htmlk.matchAll(/<b>(\d{7}).+?(Type:<b>([^<]+))<.+?Status/g);						
					for (const match of fmatches) {
						
						const fullMatch = match[0]; // The full match
						const bookingNumber = match[1]; // The 7-digit booking number
						const type = match[2]; // The 'Type' value

						if (fullMatch.toLowerCase().includes(keywordsToCheckSuburb.toLowerCase())) {
						//	alert(keywordsToCheckSuburb);
						//	alert(fullMatch);
							const cCheck = htmlEncode(keywordsToCheck);
					//		alert(cCheck);
							if (fullMatch.toLowerCase().includes(cCheck.toLowerCase())) {
							//	alert(keywordsToCheck);
							//	alert(fullMatch);
								markSameClient = true;
							}else{
									markSameClient = false;
							}		
							
							if (keywordsToCheck.some(keyword => fullMatch.toLowerCase().includes(keyword.toLowerCase()))) {
							//	alert(keywordsToCheck);
							//	alert(fullMatch); 
								markSameClient = true;
	
							}else{
								markSameClient = false;
							}
							
		
							
							if (gCourt === true){
								
							//	
								
								
								if (fullMatch.toLowerCase().includes("court")) {		
									markSuburbH = true;
									

									if (isMention === true){
										let resultAsStringRep = '<span class="markYellow">' + 'MENTION' +  "</span>" ;
										//let highlightedClientName = fullNesb.replace(regex, `<span class="markClient">$1</span>`);
										fullMatchN = fullMatch.replace("Mention", resultAsStringRep);
										htmlk = htmlk.replace(fullMatch, fullMatchN);
									//	fieldset3.innerHTML = htmlk;
										
										let resultAsStringRep2 = '<span class="markYellow">' + 'AVO/ADVO application' +  "</span>" ;
										//let highlightedClientName = fullNesb.replace(regex, `<span class="markClient">$1</span>`);
										fullMatchN = fullMatch.replace("AVO/ADVO application", resultAsStringRep2);
										htmlk = htmlk.replace(fullMatch, fullMatchN);
										
										
										if (type.toLowerCase().includes('block booking')){
											 
											
											let resultAsStringRep = '<span class="markYellow">' + 'BLOCK BOOKING' +  "</span>" ;
											fullMatchN1 = fullMatch.replace(type, resultAsStringRep);
											htmlk = htmlk.replace(fullMatch, fullMatchN1);
										//	fieldset3.innerHTML = htmlk;
										}														
									
									}
								
									// Replace all matching instances of resultAsStringTarget with resultAsStringRep
									
								//	alert(enableSuburb);
									
									 
								} else{
									markSuburbH = false;
								}			
							}
							
							
							
							
							
							
							if (gPolice === true){
								if (fullMatch.toLowerCase().includes("police")) {	
									markSuburbH = true;	

								}else{
									markSuburbH = false;
								}												
							}
							
						
							//*	
													
						//	if (enableSuburb === true && (markSuburbH === true || markSameClient === true)) {
							if ((enableSuburb === true && markSuburbH === true && gCourt === true)|| (enableSuburb === true && gCourt === false && (markSuburbH === true || markSameClient === true))) {								
								
							 																																
								let suburbMatchPattern = new RegExp(`<b>${bookingNumber}.+?Suburb:<b> ([^<]+)`, 'g');
								
	
								// Use the dynamically created regex pattern in the match
								let suburbMatch = htmlk.match(suburbMatchPattern);										
																		 
									//alert(suburbMatch[0]);
								let matches = [...htmlk.matchAll(suburbMatchPattern)];	
								if (matches.length > 0) {
									
									let suburbMatch = matches[0]; // First match
									
								//	alert(suburbMatch[1]); // Captured group (suburb value)
									
									mSuburb = suburbMatch[1]
									
														
									var p1 = "Suburb:<b> ";
									var p2 = mSuburb;
									let resultAsStringRep =  p1 + '<span class="markSuburb">' + mSuburb +  "</span>" ;
									let resultAsStringTarget = p1 + p2;
									fullMatchN = suburbMatch[0].replace(resultAsStringTarget,resultAsStringRep);
									//	alert(fullMatchN);
									htmlk = htmlk.replace(suburbMatch[0], fullMatchN);

								}  
							 
							}	
							
							//*/						
							
						}
					}
					
					   
					// This section only highlights the client 
					let tempDiv = document.createElement('div');
					tempDiv.innerHTML = htmlk; // Set the HTML string to the temporary element

					// Use querySelectorAll to find all <td> elements where client information is present
					let jobElements = tempDiv.querySelectorAll('td'); 
					
					
					jobElements.forEach(td => {
					// Get the inner HTML of each <td> to manipulate the client names
						let tdHtml = td.innerHTML;
					//	alert(tdHtml );

						// Use a regular expression to match the client name inside "Client: <b>...</b>, NESB:"
						let clientMatch = tdHtml.match(/Client:\s*<b>(.*?)<\/b>,\s*NESB:/);

						if (clientMatch && clientMatch[1]) {
							let fullClient = clientMatch[0]; // Extract the client name
							let clientName = clientMatch[1]; // Extract the client name
						//	alert(clientName);
							
						//	const regex = new RegExp(`\\b(${keywordsToCheck.join('|')})\\b`, 'gi');  // NESB
							const encodedKeywords = keywordsToCheck.map(keyword => htmlEncode(keyword));
							const regex = new RegExp(`\\b(${encodedKeywords.join('|')})\\b`, 'gi');  // NESB
							
							
						
//							if (enableClient === true && markSameClient === true) {
							if (enableClient === true) {

							//	alert();
							
									let highlightedClientName = fullClient.replace(regex, `<span class="markClient">$1</span>`);
									htmlk = htmlk.replace(fullClient, highlightedClientName);
							}
																								
						}
					});
										 					
					fieldset3.innerHTML = htmlk;
					 					
				}
				
			}
		
	
	 }
	
	//*/

	//alert(fieldset1.innerHTML);
		urlViewTest  = 'app_cd=fcls&app_form_cd=fcls7066&_template=logo&&own_le_id=3&item_id=';
		urlViewTest2 = 'app_cd=fcls&app_form_cd=fcls7066&_template=logo&&own_le_id=3&mode=edit&item_id=';
				//		app_cd=FCLS&app_form_cd=FCLS7066&_template=logo&&own_le_id=3&mode=edit&item_id=2981782
		let tUrl = window.location.href.toLowerCase();
		
 	//if ((tUrl.includes("showol")) || (tUrl.includes(urlViewTest)) || (tUrl.includes(urlViewTest2))) {
 	if (window.location.href.includes("showOL")) {

		//alert();
		const xpathPanels = '/html/body/div[2]/div[4]/form/div/fieldset[4]';
		const fieldset5 = getElementByXPath(xpathPanels, document);
		
		const xpathPanels1 = '/html/body/div[2]/div[4]/form/div/fieldset[5]';
		const fieldset55 = getElementByXPath(xpathPanels1, document);
		  
		if (fieldset5) { 
			let htmlk = fieldset5.innerHTML;
			//const regex = /Casual client/g;
			
			let highlightedAccept = '<span class="markYellow">Resource accept job</span>';
			htmlk = htmlk.replace("Resource accept job", highlightedAccept);
			
		//	let highlightedAccept2 = '<span class="markYellow">Withdrawn</span>';
		//	htmlk = htmlk.replace("Withdrawn", highlightedAccept2);
			
			
			let highlightedAccept3 = '<span class="markYellow">Forced by LS Amend</span>';
			htmlk = htmlk.replace("Forced by LS Amend", highlightedAccept3);
			
			
			
			fieldset5.innerHTML = htmlk;
		}
		if (fieldset55){
			
			let htmlk = fieldset55.innerHTML;
			//alert(htmlk);
			//const regex = /Casual client/g;
			
			let highlightedAccept = '<span class="markYellow">Resource accept job</span>';
			htmlk = htmlk.replace("Resource accept job", highlightedAccept);
			
			let highlightedAccept2 = '<span class="markYellow">Withdrawn</span>';
			htmlk = htmlk.replace("Withdrawn", highlightedAccept2);
			
			fieldset55.innerHTML = htmlk;
			
		}

		const xpath4 = '/html/body/div[2]/div[4]/form/div/fieldset[1]';
		const fieldset4 = getElementByXPath(xpath4, document);
		const osdbd = fieldset4.innerHTML.toLowerCase().includes("other same day bookings");

	//	const enableNesb = getStatus('enableNesb');
	//	alert(enableNesb);
		if (enableNesb === true) {
			if (fieldset4) { 
			
				if (osdbd){	
			// Check if keywordsToCheckNesb is empty first
				if (keywordsToCheckNesb.length === 0) {
					console.log("keywordsToCheckNesb is empty, skipping replacement.");
				} else {
					// If not empty, proceed with the replacement
					let htmlk = fieldset4.innerHTML;

					// Create the regex pattern from keywordsToCheckNesb
		//			const regex = new RegExp(`\\b(${keywordsToCheckNesb.join('|')})\\b`, 'gi');

					// Wrap the matched keyword in <span> with class "markNesb"
		//			htmlk = htmlk.replace(regex, `<span class="markNesb">$1</span>`);
					
					
						let tempDiv = document.createElement('div');
						tempDiv.innerHTML = htmlk; // Set the HTML string to the temporary element

						// Use querySelectorAll to find all <td> elements where client information is present
						let jobElements = tempDiv.querySelectorAll('td'); 
						
						
						jobElements.forEach(td => {
						// Get the inner HTML of each <td> to manipulate the client names
						let tdHtml = td.innerHTML;

						// Use a regular expression to match the client name inside "Client: <b>...</b>, NESB:"
						let suburbMatch = tdHtml.match(/NESB:\s*<b>(.*?)<\/b>,\s*Suburb:/);

						if (suburbMatch && suburbMatch[1]) {
							let fullSuburb = suburbMatch[0]; // Extract the client name
							//let clientName = clientMatch[1]; // Extract the client name
							//alert(clientName);
							
							const regex = new RegExp(`\\b(${keywordsToCheckNesb.join('|')})\\b`, 'gi');  // NESB
						
													
							let highlightedNesbName = fullSuburb.replace(regex, `<span class="markNesb">$1</span>`);
							htmlk = htmlk.replace(fullSuburb, highlightedNesbName);
							
							
							}
						});
					
					
					// Optionally alert or log the keywords
					//alert(keywordsToCheckNesb);
					
					// Update the innerHTML of fieldset4
					fieldset4.innerHTML = htmlk;
				}
				}
			}
			
		}
	}
	
  }

  // Keywords to monitor on the page

  // XPath for the element to check in the iframe
  const iframeId = 'iframe'; // Target iframe using its ID
  const xpathForIframeElement = '/html/body/div[2]/div/form/div/fieldset[3]/div[7]/div/textarea'; // XPath inside the iframe
  const inputXPath = '/html/body/div[2]/div/form/div/fieldset[3]/div[3]/div[2]/input'; // XPath for input field
  const labelXPath = '/html/body/div[2]/div/form/div/fieldset[3]/div[3]/div[2]/label'; // XPath for label to highlight
  const additionalInputXPath = '/html/body/div[2]/div/form/div/fieldset[4]/div[1]/div/input[2]'; // New XPath for additional input field
  const additionalLabelXPath = '/html/body/div[2]/div/form/div/fieldset[4]/div[1]/div/label'; // New XPath for additional label to highlight
  const xpathToExtract = '/html/body/div[2]/div[3]/div[1]';
  const xpathToExtract2 = '/html/body/div[2]/div[2]/div[1]';
  

  
  ///html/body/div[2]/div[2]/div[1]

  // New XPath for the main page target element
//  const mainPageXPath = '/html/body/div[2]/div[4]/form/div/fieldset[1]'; // XPath for the element on the main page
						///html/body/div[2]/div[4]/form/div/table/tbody/tr/td
						
//	const mainPageXPath = '/html/body/div[2]/div[4]/form/div'; // XPath for the element on the main page
//	const mainPageXPath = '/html/body/div[2]/div[4]/form/div/fieldset[1]/table/tbody/tr/td'; // Updated XPath for the td elements within the fieldset

  // Function to start monitoring after the page is fully loaded
  
  //////////////////////////////
  ////////
  ///
  
  function fixBulkphones(){
	  // Get all anchor tags in the document
		const anchors = document.querySelectorAll('a');

		// Regex pattern to match the specific href and phone number
		const phoneLinkPattern = /href="(javascript:var.+?submit\(\))" class.+?(\d{10})/;

		// Iterate over all anchor elements
		anchors.forEach(anchor => {
			const hrefValue = anchor.outerHTML; // Get the outer HTML to apply regex
			const match = phoneLinkPattern.exec(hrefValue); // Apply regex to find a match

			if (match) {
				const phoneNumber = match[2]; // Extract the 10-digit phone number from the regex match
				// Replace the href with "tel:" link and the matched phone number
				anchor.href = `tel:${phoneNumber}`;
			}
		});

  }
  
  
  
  function trnCostingWork(){
	 ///
	// alert();
	
	const element = getElementByXPath(xpathToExtract, document);
		if (element) {
			const extractedText = element.textContent.trim(); // Extract the text content and trim any extra spaces

	

			if (extractedText.includes("English to")){
				
				
				wordNoPath = '/html/body/div[2]/div[4]/form/div/fieldset[2]/div[4]/div/label/b';
	 			
				const WordNumberElement = getElementByXPath(wordNoPath, document);
	 
				let htmlk = WordNumberElement.innerHTML;
				textToHighlight = "Number of words"
				const regex = new RegExp(textToHighlight, "g");
				htmlk = htmlk.replace(regex, `<span class="markYellow">Count English Source</span>`);
				WordNumberElement.innerHTML = htmlk;
				
			//alert(htmlk);
				showNotificationBootstrapNotify('Check for source English word count');
				
				
				
				
			}
		}
		
	
  }
  
  function trnEditorWork(){
	 ///
	// alert();
	SourceTypePath = '/html/body/div[2]/div[4]/form/div/fieldset[2]/div[1]/div/label';
	SourceTypePath2 = '/html/body/div[2]/div[4]/form/div/fieldset[2]/div[1]/div/input[2]';
				
	const SourceTypeElement = getElementByXPath(SourceTypePath, document);
	const SourceTypeElement2 = getElementByXPath(SourceTypePath2, document);
	//alert(SourceTypeElement2.value);
	
	//if (SourceTypeElement && !SourceTypeElement2.value.toLowerCase().includes('original')) {
	if (SourceTypeElement && SourceTypeElement2 && !SourceTypeElement2.value.toLowerCase().includes('original sighted')) {

	//	alert();
		 const textToHighlight = "Source document sighted";
				let htmlk = SourceTypeElement.innerHTML;

				if (htmlk.includes(textToHighlight)) {
					const regex = new RegExp(textToHighlight, "g");
					htmlk = htmlk.replace(regex, `<span class="markYellow">${textToHighlight}</span>`);
					SourceTypeElement.innerHTML = htmlk;
				}
		//	alert(htmlk);
		showNotificationBootstrapNotify('Check Sighted Status');
		
	}
	
	const checkbox = document.getElementById("LS_BookingTranslation_e_bookingFeeEstimateEntity_e_cust_affid_fee_yn_disp");

	if (checkbox && checkbox.checked) {
	  // Find the element containing "Affidavit required"
	  // For example, if it's inside a specific container, adjust the selector accordingly.
	  // Here, I just search the whole document body for simplicity:

	  const bodyHTML = document.body.innerHTML;
	  const textToHighlight = "Affidavit required";
	  
	  if (bodyHTML.includes(textToHighlight)) {
		const regex = new RegExp(textToHighlight, "g");
		document.body.innerHTML = bodyHTML.replace(regex, `<span class="markNotesOld">${textToHighlight}</span>`);
		 showNotificationBootstrapNotify('Affidavit Required');
		 
	  }
	}

	
  }
  
  function CancelChain(){
	 ///
	tPath = '/html/body/div[2]/div[4]/form/div/fieldset[3]/table';
	const element = getElementByXPath(tPath, document);
	if (element) {

			const today = new Date();
			const todayString = ("0" + today.getDate()).slice(-2) + "/" + ("0" + (today.getMonth() + 1)).slice(-2) + "/" + today.getFullYear();
		//	const todayString = todayString.toString();
			htmlk = element.innerHTML;
		//	const todayString = "13/11/2024";
			
//			const regex2 = /12\/11\/2024/g;
//			htmlk = htmlk.replace(regex2, '<span class="markYellow">12/11/2024</span>');

			const regex2 = new RegExp(todayString.replace(/\//g, "\\/"), "g"); // Escapes the slashes for regex
			htmlk = htmlk.replace(regex2, `<span class="markYellow">${todayString}</span>`);
			element.innerHTML = htmlk;
		//	alert(htmlk);
	}
	
  }
  
  
  
  function CountryPrivateWork(){
	 
	tPath = '/html/body/div[2]/div[3]/form/div/fieldset[2]';
	const element = getElementByXPath(tPath, document);
	if (element) {
		 

			// Select the parent div containing the content
			const elements = document.querySelectorAll('div[title]');
			//shown = false
			// Loop through each element to find and replace "Country" text
			elements.forEach(element => {
				//if ((shown === false) && (element.innerHTML.includes('INT,'))){
				if (element.innerHTML.includes('INT,') || element.innerHTML.includes('AVL,')){
				//	alert(element.innerHTML);
				//	shown = true;
					const regex2 = /Casual client/g;
					element.innerHTML = element.innerHTML.replace(regex2, '<span class="markYellow">Casual client</span>');
					
					const regex = /\(Country\)/g;
					element.innerHTML = element.innerHTML.replace(regex, '<span class="markYellow">(Country)</span>');
				}
		
			if (element.innerHTML.includes('TRN,') ){
				//	alert(element.innerHTML);
				//	shown = true;
					const regex2 = /Affidavit/g;
					element.innerHTML = element.innerHTML.replace(regex2, '<span class="markYellow">Affidavit</span>');
					
					 
				}
							
			});

					 
		
	}	
	  
  } 
	  
	  function getAdjustedTime() {
			const now = new Date();

			// Subtract 1 minute
			now.setMinutes(now.getMinutes() - 1);

			// Extract hours, minutes, and AM/PM
			let hours = now.getHours();
			const minutes = String(now.getMinutes()).padStart(2, '0'); // Ensure two digits
			const ampm = hours >= 12 ? 'PM' : 'AM';

			// Convert to 12-hour format
			hours = hours % 12;
			hours = hours ? hours : 12; // If hour is 0, set it to 12

			// Combine hours and minutes in HH:mm format
			const hhmm = `${String(hours).padStart(2, '0')}:${minutes}`;

			// Return the values
			return { time: hhmm, period: ampm };
		}
  
  function CancelWork() {
	  
		
		const element = getElementByXPath(xpathToExtract, document);
		if (element) {
			const extractedText = element.textContent.trim(); // Extract the text content and trim any extra spaces
			
			
		//	if (extractedText.includes("LSR")){
				 
		//		  showNotificationBootstrapNotify("Possible Chain Booking");
		//	}		
		
		selfCancel = "app_form_cd=fcls1028&prcs_defn_cd=&_template=default&_al_action_click=1&mode=edit&state_cd=&app_cd=&item_id=";
				      //app_form_cd=FCLS1028&prcs_defn_cd=&_template=default&_al_action_click=1&mode=edit&state_cd=&app_cd=&item_id=

			//if (extractedText.includes("Cancel Appr")){
//			if (window.location.href.includes(selfCancel)){
//				alert()	
//			}			

		let ClientCancel = false;
		if (extractedText.includes("Cancel Appr")) {
			ClientCancel = true;		
			
		}
		if ((ClientCancel === true) || (window.location.href.toLowerCase().includes(selfCancel))){

				//alert(extractedText);
				if (!extractedText.includes("Not allocated yet")){
				//showNotificationBootstrapNotify("Possible Chain Booking");
					//alert(extractedText);
					let adjustedTime = getAdjustedTime();
					let adjustedT = adjustedTime.time; // e.g., 11:59
					let adjustedTAMPM = adjustedTime.period; 
					//alert(adjustedT);
					
					//const targetElement = getElementByXPath();
					//*[@id="interp_advice_tm_dt"]
					
					
					
					//const modeC = getElementByXPath('/html/body/div[2]/div[4]/form/div/fieldset[2]/div[7]/div/select', document);
					
					const dropdown = document.querySelector('select[name="interp_confirm_cd"]');

					if (dropdown) {
						// Set the value to "EMAIL"
						dropdown.value = "EMAIL";

						// Trigger a change event to notify listeners of the selection
						const event = new Event('change', { bubbles: true });
						dropdown.dispatchEvent(event);

						 
					}
					
					
					
					//alert(adjustedTAMPM);    
					  
					const today = new Date();
					const day = String(today.getDate()).padStart(2, '0');
					const month = String(today.getMonth() + 1).padStart(2, '0');
					const year = today.getFullYear();
					const todayFormatted = `${day}/${month}/${year}`;
					const todayFormattedString = todayFormatted.toString();
					
					const changeEvent = new Event('change', { bubbles: true });
					
					//modeC.value = "EMAIL";
					//modeC.dispatchEvent(changeEvent);
					if (ClientCancel === false) {
						const dateEntry = getElementByXPath('//*[@id="interp_advice_tm_dt"]', document);
						const timeEntry = getElementByXPath('//*[@id="interp_advice_tm_t"]', document);
						const AMPMEntry = getElementByXPath('//*[@id="interp_advice_tm_p"]', document);
						const dateEntryC = getElementByXPath('//*[@id="client_rqst_tm_dt"]', document);
						const timeEntryC = getElementByXPath('//*[@id="client_rqst_tm_t"]', document);
						const AMPMEntryC = getElementByXPath('//*[@id="client_rqst_tm_p"]', document);
						
						
						dateEntryC.value = todayFormattedString;
						dateEntryC.dispatchEvent(changeEvent);
						timeEntryC.value = adjustedT;
						dateEntryC.dispatchEvent(changeEvent);
						AMPMEntryC.value = adjustedTAMPM;
						dateEntryC.dispatchEvent(changeEvent);
						
						dateEntry.value = todayFormattedString;
						dateEntry.dispatchEvent(changeEvent);
						timeEntry.value = adjustedT;
						dateEntry.dispatchEvent(changeEvent);
						AMPMEntry.value = adjustedTAMPM;
						dateEntry.dispatchEvent(changeEvent);
					} else {
						//alert('ClientCancel');
						const dateEntry = getElementByXPath('//*[@id="interp_advice_tm_dt"]', document);
						const timeEntry = getElementByXPath('//*[@id="interp_advice_tm_t"]', document);
						const AMPMEntry = getElementByXPath('//*[@id="interp_advice_tm_p"]', document);
						 
						dateEntry.value = todayFormattedString;
						dateEntry.dispatchEvent(changeEvent);
						timeEntry.value = adjustedT;
						dateEntry.dispatchEvent(changeEvent);
						AMPMEntry.value = adjustedTAMPM;
						dateEntry.dispatchEvent(changeEvent);
					}
					
				//	extractedText = 'Date: 12/12/2024, Time (NSW time): 09:30 AM';
				//	alert(todayFormattedString);
				//	const todayFormattedString = "04/11/2024";

					const dateTimeRegex = /Date:\s*(\d{2}\/\d{2}\/\d{4}),\s*Time\s\(NSW time\):\s*(\d{2}:\d{2})\s*(AM|PM)/;
					const dateTimeMatch = extractedText.match(dateTimeRegex);

					if (dateTimeMatch) {
						const extractedDateStr = dateTimeMatch[1]; // Extracted date in "DD/MM/YYYY" format
						const extractedTimeStr = dateTimeMatch[2]; // Extracted time in "HH:mm" format
						const extractedPeriod = dateTimeMatch[3];  // AM or PM

						 

						// Parse extracted date
						const [extractedDay, extractedMonth, extractedYear] = extractedDateStr.split('/').map(Number);

						// Parse extracted time
						let [hours, minutes] = extractedTimeStr.split(':').map(Number);
						if (extractedPeriod === 'PM' && hours !== 12) {
							hours += 12; // Convert PM hours to 24-hour format
						} else if (extractedPeriod === 'AM' && hours === 12) {
							hours = 0; // Convert 12 AM to 0 hours
						}

						// Create a Date object for the extracted date and time
						const extractedDateTime = new Date(extractedYear, extractedMonth - 1, extractedDay, hours, minutes);

						// Calculate the difference in milliseconds
						const timeDiff = extractedDateTime - today; // Difference in milliseconds
						let daysDiff = (timeDiff / (1000 * 60 * 60 * 24)); // Convert to days (fractional)
						
						
						if (daysDiff > 2 && daysDiff < 5) {
							//alert(daysDiff);
							const tomorrow = new Date(today);
							tomorrow.setDate(today.getDate() + 1);

							const dayAfterTomorrow = new Date(today);
							dayAfterTomorrow.setDate(today.getDate() + 2);

							const isTomorrowWeekend = tomorrow.getDay() === 0 || tomorrow.getDay() === 6; // Sunday or Saturday
							const isDayAfterTomorrowWeekend = dayAfterTomorrow.getDay() === 0 || dayAfterTomorrow.getDay() === 6; // Sunday or Saturday

							if (isTomorrowWeekend && isDayAfterTomorrowWeekend) {
							//	alert(daysDiff);
								daysDiff = daysDiff - 2; // Deduct 2 days if both are weekends
							}
							//alert(daysDiff);
						} 
						if (daysDiff > 1 && daysDiff < 3) {
						//	alert(daysDiff);
							const targetElement = getElementByXPath('/html/body/div[2]/div[4]/form/div/fieldset[1]/div[2]/div');
							const newLineElement = document.createElement("p");  // Use a <p> tag for a new line
							//let resultAsStringRep = '<span class="markYellow">' + "Full day option" +  "</span>" ;

							newLineElement.textContent =  "***********************************CANCELLING MORE THAN " + Math.floor(daysDiff) + " DAY AHEAD -- NONE // 24-48 HRS";   // Set the desired text content
							targetElement.parentNode.insertBefore(newLineElement, targetElement.nextSibling); 
						}else if (daysDiff > 2) {
						//	alert(daysDiff);
							const targetElement = getElementByXPath('/html/body/div[2]/div[4]/form/div/fieldset[1]/div[2]/div');
							const newLineElement = document.createElement("p");  // Use a <p> tag for a new line
							//let resultAsStringRep = '<span class="markYellow">' + "Full day option" +  "</span>" ;

							newLineElement.textContent =  "***********************************CANCELLING MORE THAN " + Math.floor(daysDiff) + " DAYS AHEAD -- NONE";   // Set the desired text content
							targetElement.parentNode.insertBefore(newLineElement, targetElement.nextSibling); 
						} 
						
						if (daysDiff < 1) {
						//	alert(daysDiff);
							const targetElement = getElementByXPath('/html/body/div[2]/div[4]/form/div/fieldset[1]/div[2]/div');
							const newLineElement = document.createElement("p");  // Use a <p> tag for a new line
							//let resultAsStringRep = '<span class="markYellow">' + "Full day option" +  "</span>" ;

							newLineElement.textContent =  "*********************************** !!! CANCELLING LESS THAN 24 HOURS !!!";   // Set the desired text content
							targetElement.parentNode.insertBefore(newLineElement, targetElement.nextSibling); 
						} 
						
						//alert(daysDiff);
					}
					
				 
					
					if (extractedText.includes(todayFormattedString)) {
					//	alert("Today's date is in the text.");
						
						
						const targetElement = getElementByXPath('/html/body/div[2]/div[4]/form/div/div[2]/input[1]');
						
						// Create a new element for the text with a line break
						if (targetElement) {
							const newLineElement = document.createElement("p");  // Use a <p> tag for a new line
							//let resultAsStringRep = '<span class="markYellow">' + "Full day option" +  "</span>" ;

							newLineElement.textContent =  "!!! SAME DAY JOB CANCEL WARNING !!! " ;   // Set the desired text content
							targetElement.parentNode.insertBefore(newLineElement, targetElement.nextSibling);  // Insert after the target
						}
					}
					
					
				}	
			} else {
				
				
				
				
			}
	  
		}

  }  
  
  
  
  function AmendWork() {
	  
		
		const element = getElementByXPath(xpathToExtract, document);
		if (element) {
			const extractedText = element.textContent.trim(); // Extract the text content and trim any extra spaces

			
		//	if (extractedText.includes("LSR")){
		//		alert();
		//		  showNotificationBootstrapNotify("Possible Chain Booking");
		//	}		

			if (extractedText.includes("Amend appr")){
				//alert(extractedText);
				if (!extractedText.includes("Not allocated yet")){
				//showNotificationBootstrapNotify("Possible Chain Booking");
					//alert(extractedText);
					
					const today = new Date();
					const day = String(today.getDate()).padStart(2, '0');
					const month = String(today.getMonth() + 1).padStart(2, '0');
					const year = today.getFullYear();
					const todayFormatted = `${day}/${month}/${year}`;
					const todayFormattedString = todayFormatted.toString();
				//	alert(todayFormattedString);
				//	const todayFormattedString = "06/11/2024";

					// Check if today's date is in the extractedText
					if (extractedText.includes(todayFormattedString)) {
					//	alert("Today's date is in the text.");
						
						
						const targetElement = getElementByXPath('/html/body/div[2]/div[4]/form/div/div[2]/input[1]');
						
						// Create a new element for the text with a line break
						if (targetElement) {
							const newLineElement = document.createElement("p");  // Use a <p> tag for a new line
							//let resultAsStringRep = '<span class="markYellow">' + "Full day option" +  "</span>" ;

							newLineElement.textContent =  "!!! SAME DAY JOB AMEND WARNING !!! " ;   // Set the desired text content
							targetElement.parentNode.insertBefore(newLineElement, targetElement.nextSibling);  // Insert after the target
						}
					}
				}	
			}
	  
		}

  }  
  
  
  function IRBProcessWork() {
	  ////
	  
	  
	 window.addEventListener('load', () => {
	  country = false;
	  cTickPath = '//*[@id="LS_BookingInterpreting_e_intReconEntity_e_country_assign_yn_disp"]';
	  const targetPart = getElementByXPath(cTickPath, document);
	 
	  if (targetPart && targetPart.checked) {
		  GSTTickPath = '//*[@id="oth_country_crc_gst_disp"]';
	  	  const GstPart = getElementByXPath(GSTTickPath, document);
		 // GstPart.checked = false;
		  
		  if (GstPart) {
        // Programmatically untick the checkbox
			GstPart.checked = false;

			// Create and dispatch a change event to simulate user interaction
			const changeEvent = new Event('change', { bubbles: true });
			GstPart.dispatchEvent(changeEvent);
			
			console.log('Checkbox unticked and change event triggered');
		}
			
			ExtractHeader(xpathToExtract);
			
			
			IRBnumPath = '/html/body/div[2]/div[4]/form/div/fieldset[3]/div[1]/div/input';
			const IRBnumElement = getElementByXPath(IRBnumPath, document);
			//alert(INT_number);
			if (!IRBnumElement || typeof IRBnumElement.value === 'undefined'|| IRBnumElement.value === "") {
	//			alert(IRBnumElement.value);
				IRBnumElement.value = INT_number;
			}
			
			
			
			
			
			
			FwdJpath = "/html/body/div[2]/div[4]/form/div/div[7]/fieldset[3]/div[2]/div/input";
			const FwdJpathElement = getElementByXPath(FwdJpath, document);
			if (FwdJpathElement.value === ""){
				
				FwdJpathElement.value = keywordsToCheck.join('|');
				//alert(keywordsToCheck.join('|'));
			}
			
			FwdJpath2 = "/html/body/div[2]/div[4]/form/div/div[7]/fieldset[3]/div[4]/div/input";
			const FwdJpathElement2 = getElementByXPath(FwdJpath2, document);
			if (FwdJpathElement2.value === ""){
				//ExtractHeader(xpathToExtract);
				FwdJpathElement2.value = keywordsToCheck.join('|');
				//alert(keywordsToCheck.join('|'));
			}
			
			
			
			kmPath = '/html/body/div[2]/div[4]/form/div/div[7]/fieldset[3]/div[11]/div[1]/input';
			const kmValue = getElementByXPath(kmPath, document);
			
			if (!kmValue || typeof kmValue.value === 'undefined'|| kmValue.value === "" || kmValue.value === "0") {
				
				
			} else {
				
			//	alert(kmValue.value);		
				
				//alert(htmlk);
				let htmlk = document.documentElement.innerHTML;
				let resultAsStringRep = '<span class="markYellow">' + "Vehicle's engine size" +  "</span>" ;
				htmlk = htmlk.replace("Vehicle's engine size", resultAsStringRep);
				document.documentElement.innerHTML = htmlk;
			}
			
			
			
	  }	
	  
	 });
	  
	}	  
  

  function IRBwork() {
	  //
	  
	  
	  const xpathToClick = '/html/body/div[2]/div[4]/form/div/fieldset[5]/a';
		const elementToClick = getElementByXPath(xpathToClick);

		if (elementToClick) {
			elementToClick.click(); // Simulate click
		}
	  
	    const xpathToExtractA = '/html/body/div[2]/div[4]/form/div/fieldset[12]/div';
		const xpathToAppendA = '/html/body/div[2]/div[4]/form/div/fieldset[3]';

		const elementToExtract = getElementByXPath(xpathToExtractA);
		const elementToAppend = getElementByXPath(xpathToAppendA);

		if (elementToExtract && elementToAppend) {
			// Get the inner HTML of the source element
			const innerHTMLToAdd = elementToExtract.innerHTML;

			// Append it to the destination element's existing HTML
			elementToAppend.innerHTML += innerHTMLToAdd;
		}
	  
	  country = false;
	  cTickPath = '//*[@id="LS_BookingInterpreting_e_intReconEntity_e_country_assign_yn_disp"]';
	  const targetPart = getElementByXPath(cTickPath, document);
	 
	  if (targetPart && targetPart.checked) {
		  country = true;
	//	  alert("country");
		  let htmlk = document.documentElement.innerHTML;
		  
	//	  payPath = '//*[@id="irb_lsr_total_cy_c"]';
		  
		  
		  const totalElement = getElementByXPath('//*[@id="irb_lsr_total_cy_c"]', document);

			if (totalElement) {
				const totalValue = parseFloat(totalElement.value);

				// Check if the value is greater than 800
				if (!isNaN(totalValue) && totalValue > 800) {
					//alert("Value is greater than 200.");
					showNotificationBootstrapNotify("Total pay too high");
					
				}
			}
		  
			const countryCostPath = '//*[@id="LS_BookingInterpreting_ClaimRecon_e_intReconEntity_e_irb_cust_oth_cty_cy_c"]';
			const addGSTpath = '/html/body/div[2]/div[4]/form/div/div[7]/fieldset[2]/div[4]/div[1]/label';

			// Get elements
			const countryCost = getElementByXPath(countryCostPath, document);
			const addGSTLabel = getElementByXPath(addGSTpath, document);



			if (countryCost && addGSTLabel) {
				let xValue = "";

				if (typeof countryCost.value !== 'undefined' && countryCost.value !== "") {
				//	xValue = (countryCost.value * 1.1).toFixed(2); // calculate Ex-GST
					let cleanValue = countryCost.value.toString().replace(/,/g, "");

					// Parse the cleaned value to a float
					let numericValue = parseFloat(cleanValue);
				
					xValue = (Math.floor(numericValue * 1.1 * 100) / 100);
					xValue = xValue.toFixed(2);

					// Only modify the label's text, avoid touching innerHTML directly if not needed
					const originalText = addGSTLabel.textContent;
					

					if (originalText.includes("Tick if inclucing GST")) {
						
						let resultAsStringRep = `Tick if including GST - Value incl. GST <span class="markYellow"> $${xValue}` +  "</span>" ;		
						htmlk = htmlk.replace("Tick if inclucing GST", resultAsStringRep);
					}
				}
			}


		  
		  
		  fDaypath = '//*[@id="LS_BookingInterpreting_e_intReconEntity_e_full_day_yn_disp"]';
		  const fDay = getElementByXPath(fDaypath, document);
	 
		  if (fDay && fDay.checked) {
		//	alert(fDay.value);
			
			let resultAsStringRep = '<span class="markYellow">' + "Full day option" +  "</span>" ;
			htmlk = htmlk.replace("Full day option", resultAsStringRep);
			
			
			
		  } else {
			  
			//  let resultAsStringRep = '<span class="markYellow">' + "Full day option" +  "</span>" ;
			//htmlk = htmlk.replace("Full day option", resultAsStringRep);
		  }	
		//   alert(targetPart.value);
			
			kmPath = '/html/body/div[2]/div[4]/form/div/div[7]/fieldset[3]/div[13]/div[1]';
			const kmValue = getElementByXPath(kmPath, document);
			
			if (!kmValue || typeof kmValue.value === 'undefined' || kmValue.value === "") {
		 
				
			} else {
				
						
				
			//	alert(htmlk);
				
				let resultAsStringRep = '<span class="markYellow">' + "Vehicle's engine size" +  "</span>" ;
				htmlk = htmlk.replace("Vehicle's engine size", resultAsStringRep);
				
			}
			
			
			const timeElement = getElementByXPath('//*[@id="LS_BookingInterpreting_e_intReconEntity_e_irb_cust_asg_sttm_tm_t"]', document);
			const periodElement = getElementByXPath('//*[@id="LS_BookingInterpreting_e_intReconEntity_e_irb_cust_asg_sttm_tm_p"]', document);

			if (timeElement && periodElement) {
				const timeValue = timeElement.value; // e.g., "09:30"
				const periodValue = periodElement.value; // e.g., "AM" or "PM"

				if (periodValue === "AM") {
					const [hours, minutes] = timeValue.split(':').map(Number);

			// Check if time is earlier than 6:00 AM
					if (hours < 6) {
						//alert("Time is earlier than 6:00 AM and it's AM.");
						 
						let resultAsStringRep = '<span class="markYellow">' + "Assignment start date/time" +  "</span>" ;
						htmlk = htmlk.replace("Assignment start date/time", resultAsStringRep);

					}
				}
			}
		//	alert();
			
			const timeElement2 = getElementByXPath('//*[@id="LS_BookingInterpreting_e_intReconEntity_e_irb_cty_fwd_tm_t"]', document);
			const periodElement2 = getElementByXPath('//*[@id="LS_BookingInterpreting_e_intReconEntity_e_irb_cty_fwd_tm_p"]', document);

			if (timeElement2 && periodElement2) {
				const timeValue = timeElement2.value; // e.g., "09:30"
				const periodValue = periodElement2.value; // e.g., "AM" or "PM"

				if (periodValue === "AM") {
					const [hours, minutes] = timeValue.split(':').map(Number);

			// Check if time is earlier than 6:00 AM
					if (hours < 6) {
						//alert("Time is earlier than 6:00 AM and it's AM.");
						 
						let resultAsStringRep = '<span class="markYellow">' + "Time left normal work area (NSW time)" +  "</span>" ;
						htmlk = htmlk.replace("Time left normal work area (NSW time)", resultAsStringRep);

					}
				}
			}

		//	alert();
			const timeElement3 = getElementByXPath('//*[@id="LS_BookingInterpreting_e_intReconEntity_e_irb_cty_ret_tm_t"]', document);
			const periodElement3 = getElementByXPath('//*[@id="LS_BookingInterpreting_e_intReconEntity_e_irb_cty_ret_tm_p"]', document);

			if (timeElement3 && periodElement3) {
			//	alert();
				const timeValue = timeElement3.value; // e.g., "09:30"
				const periodValue = periodElement3.value; // e.g., "AM" or "PM"

				if (periodValue === "PM") {
					const [hours, minutes] = timeValue.split(':').map(Number);

			// Check if time is earlier than 6:00 AM
				//	if (hours > 6) {
				//	if ((hours > 4 || (hours === 4 && minutes > 30)) && hours !== 12) {
					//	alert();
					if ((hours > 6 || (hours === 6 && minutes > 30)) && hours !== 12) {
						//alert("Time is earlier than 6:00 AM and it's AM.");
						 
						let resultAsStringRep = '<span class="markYellow">' + "Time arrived normal work area (NSW time)" +  "</span>" ;
						htmlk = htmlk.replace("Time arrived normal work area (NSW time)", resultAsStringRep);

					}
				}
			}
			
			document.documentElement.innerHTML = htmlk; 
		
	  }
	  ////
	  
	  
  }	  

  
function PIC(xpath, doc = document) {
    const element = getElementByXPath(xpath, doc);
	const element2 = getElementByXPath('//*[@id="sys_desc"]', doc);
	 // Extract the text content and trim any extra spaces
	
	
	
    if (element) {
        
		//alert();
		const extractedText = element.textContent.trim();
	
		if (extractedText.includes("Personal Injury Commission"))  {
			const highlightedAccept = '<span class="markExpTRN">Personal Injury Commission</span>';
		//	alert();
			// Replace the text inside the element using innerHTML
			element.innerHTML = element.innerHTML.replace(/Personal Injury Commission/g, highlightedAccept);
		}
		
	//	if ((extractedText.includes("7 business days")) && (extractedText.includes("SNSW"))) {
	//		const highlightedAccept = '<span class="mark7daysTRN">7 business days</span>';
		//	alert();
			// Replace the text inside the element using innerHTML
	//		element.innerHTML = element.innerHTML.replace(/7 business days/g, highlightedAccept);
	//	}
		
		
	}else{	
		
	
	if (element2) {
		
         	 const extractedText = element2.textContent.trim();
	
			if (extractedText.includes("Personal Injury Commission"))  {
			 
			const highlightedAccept = '<span class="markExpTRN">Personal Injury Commission</span>';
		//	alert();
			// Replace the text inside the element using innerHTML
			element2.innerHTML = element2.innerHTML.replace(/Personal Injury Commission/g, highlightedAccept);
		}
		
		
	//	if ((extractedText.includes("7 business days")) && (extractedText.includes("SNSW"))) {

			 
	//		const highlightedAccept = '<span class="mark7daysTRN">7 business days</span>';
		//	alert();
			// Replace the text inside the element using innerHTML
	//		element2.innerHTML = element2.innerHTML.replace(/7 business days/g, highlightedAccept);
	//	}
	}
	}
}	
  
  function TRNHeader(xpath, doc = document) {
    const element = getElementByXPath(xpath, doc);
	const element2 = getElementByXPath('//*[@id="sys_desc"]', doc);
	 // Extract the text content and trim any extra spaces
	
	
	
    if (element) {
        
		//alert();
		const extractedText = element.textContent.trim();
	
		if ((extractedText.includes("Express Service")) && (extractedText.includes("SNSW"))) {
			const highlightedAccept = '<span class="markExpTRN">Express Service</span>';
		//	alert();
			// Replace the text inside the element using innerHTML
			element.innerHTML = element.innerHTML.replace(/Express Service/g, highlightedAccept);
		}
		
	//	if ((extractedText.includes("7 business days")) && (extractedText.includes("SNSW"))) {
	//		const highlightedAccept = '<span class="mark7daysTRN">7 business days</span>';
		//	alert();
			// Replace the text inside the element using innerHTML
	//		element.innerHTML = element.innerHTML.replace(/7 business days/g, highlightedAccept);
	//	}
		
		
	}else{	
		
	
	if (element2) {
		
         	 const extractedText = element2.textContent.trim();
	
		 if ((extractedText.includes("Express Service")) && (extractedText.includes("SNSW"))) {
			 
			const highlightedAccept = '<span class="markExpTRN">Express Service</span>';
		//	alert();
			// Replace the text inside the element using innerHTML
			element2.innerHTML = element2.innerHTML.replace(/Express Service/g, highlightedAccept);
		}
		
		
	//	if ((extractedText.includes("7 business days")) && (extractedText.includes("SNSW"))) {

			 
	//		const highlightedAccept = '<span class="mark7daysTRN">7 business days</span>';
		//	alert();
			// Replace the text inside the element using innerHTML
	//		element2.innerHTML = element2.innerHTML.replace(/7 business days/g, highlightedAccept);
	//	}
	}
	}
	
  }
  
  function ExtractHeader(xpath, doc = document) {
    const element = getElementByXPath(xpath, doc);
    if (element) {
        const extractedText = element.textContent.trim(); // Extract the text content and trim any extra spaces
		
	
		 
	

		if (extractedText.includes("(Parent)")||extractedText.includes("LSR")){
			  showNotificationBootstrapNotify("Possible Chain Booking");
		}


		
		if (extractedText.includes("INIT")){
		//	alert();
			const dateInput = getElementByXPath('//*[@id="LS_BookingInterpreting_e_intBD_e_start_tm_dt"]',doc);	
			if (dateInput) {
				dateInput.value = ''; // Clear the date input value to reset
			}			
			
			const timeInput = getElementByXPath('//*[@id="LS_BookingInterpreting_e_intBD_e_start_tm_t"]',doc);	
			if (timeInput) {
				timeInput.value = ''; // Clear the date input value to reset
			}

			const timeInputAMPM = getElementByXPath('//*[@id="LS_BookingInterpreting_e_intBD_e_start_tm_p"]',doc);	
			if (timeInputAMPM) {
				timeInputAMPM.value = 'AM'; // Clear the date input value to reset
			}



			const durationInput = getElementByXPath("/html/body/div[2]/div[4]/form/div/fieldset[3]/div[7]/div[2]/input",doc);	
			if (durationInput) {
				durationInput.value = ''; // Clear the date input value to reset
			}			
			
			//
			const xpath1 = '/html/body/div[2]/div[4]/form/div/fieldset[3]/div[2]/div';
			const fieldset1 = getElementByXPath(xpath1, document);
			
			if (fieldset1) { // vendor / specific Interpreter  highlight
				htmlk = fieldset1.innerHTML
			
			
				let resultAsStringRep = '<span class="markRandom">' + 'Client reference' +  "</span>" ;
				htmlk = htmlk.replace('Client reference', resultAsStringRep);

				fieldset1.innerHTML = htmlk;
			}

			
		}
		if (extractedText.includes("Type: ,")){
			//alert(extractedText);
			//xpathRef = '/html/body/div[2]/div[4]/form/div/fieldset[3]/div[2]/div/label';
			
			const xpath1 = '/html/body/div[2]/div[4]/form/div/fieldset[3]/div[2]/div';
			const fieldset1 = getElementByXPath(xpath1, document);
			
			if (fieldset1) { // vendor / specific Interpreter  highlight
				htmlk = fieldset1.innerHTML
			
			
				let resultAsStringRep = '<span class="markRandom">' + 'Client reference' +  "</span>" ;
				htmlk = htmlk.replace('Client reference', resultAsStringRep);

				fieldset1.innerHTML = htmlk;
			}

			const xpath2 = '/html/body/div[2]/div[4]/form/div/fieldset[3]/div[8]/div';
			const fieldset2 = getElementByXPath(xpath2, document);
			
			if (fieldset2) { // vendor / specific Interpreter  highlight
				htmlk = fieldset2.innerHTML
			
			
				let resultAsStringRep = '<span class="markRandom">' + 'Full day booking' +  "</span>" ;
				htmlk = htmlk.replace('Full day booking', resultAsStringRep);

				fieldset2.innerHTML = htmlk;
			}			
						
		}
		
		
		if (extractedText.toLowerCase().includes("mention")){
			//alert("mention");
			 isMention = true; 
		}
		
		if (extractedText.toLowerCase().includes("block booking")){
			//alert("mention");
			 isMention = true; 
		}
		
		if (extractedText.toLowerCase().includes("advo")){
			//alert("advo");
			 isMention = true; 
		}

        let clientMatch = extractedText.match(/Client:\s*([^,]+)/);
        let nesbMatch = extractedText.match(/NESB:\s*([^,]+(?:,\s*[^,]+)*?)(?=, Suburb:)/);
        let suburbMatch = extractedText.match(/Suburb:\s*([^,]+)/);

        let client = clientMatch ? clientMatch[1].trim() : '';
//        client = client.replace(/DEPARTMENT OF COMMUNITIES & JUSTICE - /i, '').replace(/LOCAL COURT/i, '').trim();
        client = client.replace(/DEPARTMENT OF COMMUNITIES & JUSTICE - /i, '').trim();

        let suburb = suburbMatch ? suburbMatch[1].trim() : '';
		
		
		let INT_number_match = extractedText.match(/(\d{7})/);
		if (INT_number_match) {
			INT_number = INT_number_match[1];
		}

        let nesbNames = [];
        if (nesbMatch) {
            nesbNames = nesbMatch[1].replace('.',' ')
                .split(',')
                .map(name => name.trim())
                .filter(name => name && name !== '.' && !/\d/.test(name) && name.length >= 2 && !["NA", "Not","na","n/a","Block","BLOCK","Booking","BOOKING"].includes(name)); // Exclude "NA" or "Not"

            // Further split NESB names by spaces, if needed
            nesbNames = nesbNames.reduce((acc, name) => {
                const splitBySpace = name.split(/\s+/);
                return acc.concat(splitBySpace.filter(part => part.length >= 2 && !/\d/.test(part) && !["NA", "Not","na","n/a","Block","BLOCK","Booking","BOOKING"].includes(part))); // Exclude "NA" or "Not"
            }, []);
			
		//	nesbNames = nesbNames.filter(name => name.toLowerCase() !== "block booking");
        }

        //if (client.toLowerCase().includes("police") && !client.toLowerCase().includes("police")) {
		if (client.toLowerCase().includes("police") && !client.toLowerCase().includes("court")) {
		//	alert('Police');
			gPolice = true;
            keywordsToCheck.push("NSW Police Force"); // Add "Police" in the original case
        } else if (client) { // Only add if not empty
            keywordsToCheck.push(client);
        }


		if (client.toLowerCase().includes("court")) {
			//	alert('court');
			gCourt = true;
            //keywordsToCheck.push("NSW Police Force"); // Add "Police" in the original case
        }
		
		keywordsToCheckSuburb = suburb;
	//	alert(keywordsToCheckSuburb);

		//alert(keywordsToCheckSuburb);
		
        //keywordsToCheck.push(...nesbNames);
        
        keywordsToCheckNesb.push(...nesbNames);

        if (keywordsToCheck) {
            //alert(`Content of the element at the specified XPath: ${keywordsToCheck}`);
        } else {
            // alert('The element is empty.');
        }
    } else {
        //alert('Element not found at the specified XPath.');
    }
} 
  
  function showNotificationBootstrapNotify2(message) {
    $.notify({
                message: message
            },{
                type: 'custom',
                delay: 15000,
                
            });
  }
  
  
	   
  
  
  
  
  
  
  
  function startMonitoring() {
    monitorMainDocumentAndIframe(keywordsToCheck, iframeId, xpathForIframeElement, inputXPath, labelXPath, additionalInputXPath, additionalLabelXPath);
    
  }








//	alert();
	baseGUrl = window.location.href;

	fixPhone();
  
	fixNotes();

	RandomColors();
	
	if (window.location.href === "https://www.crclanguagelink.com.au/sys003.htm") {
		//alert("allocation");
        ExtractHeader(xpathToExtract);
		
    }
	
	if (window.location.href.includes("https://www.crclanguagelink.com.au/sys003.htm?app_form_cd=FCLS1016&_template=default&&item_id=")){
							
		//alert("allocation");
        ExtractHeader(xpathToExtract);
		
    }
	
	if (window.location.href.includes("https://www.crclanguagelink.com.au/sys003.htm?app_form_cd=FCLS1016&_template=default&item_id=")){
							
		//alert("allocation");
        ExtractHeader(xpathToExtract);
		
    }
	
	irbWorkLink = 'https://www.crclanguagelink.com.au/index.php?app_form_cd=fcls1003&prcs_defn_cd=&_template=default&_al_action_click=1&mode=edit&state_cd=&app_cd=&item_id=';
	irbWorkLink2 = 'https://www.crclanguagelink.com.au/index.php?app_form_cd=fcls1003&item_id=';
	
	if ((window.location.href.toLowerCase().includes(irbWorkLink))|(window.location.href.toLowerCase().includes(irbWorkLink2)) ){
							

        IRBwork();
		
    }
	
	contIRB = 'app_form_cd=FCLS1062&item_id=';
	contIRB2 = 'https://www.crclanguagelink.com.au/index.php?app_form_cd=FCLS1062&prcs_defn_cd=&_template=default&_al_action_click=1&mode=edit&state_cd=&app_cd=&item_id=';
	

	 if ((window.location.href.includes(contIRB))||(window.location.href.includes(contIRB2))){
		IRBProcessWork();
	} 
	

	selfCancel = "app_form_cd=fcls1028&prcs_defn_cd=&_template=default&_al_action_click=1&mode=edit&state_cd=&app_cd=&item_id=";
	cleintCancel = "app_form_cd=fcls1118&prcs_defn_cd=&_template=default&_al_action_click=1&mode=edit&state_cd=&app_cd=&item_id=";
																 
	if ((window.location.href.toLowerCase().includes(cleintCancel)) || (window.location.href.toLowerCase().includes(selfCancel)) ){
							
		//alert("CancelWork");
        CancelWork();
		
    }
	
	
	if (window.location.href.includes("https://www.crclanguagelink.com.au/index.php?app_form_cd=FCLS1007&prcs_defn_cd=&_template=default&_al_action_click=1&mode=edit&state_cd=&app_cd=&item_id=")){
							
	//	alert("AmendWork");
        AmendWork();
		
    }
	
	const backUrl = "https://www.crclanguagelink.com.au/sys003.htm?app_cd=SYS&app_ver_id=1&app_form_cd=SYS135&_template=advanced&_action=switch_menu&_action=switch_menu&menu_item_cd=ACT_LIST&menu_cd=ACTIVE_LIST";
	const baseA = 'https://www.crclanguagelink.com.au/sys003.htm?page_action=al_refresh';
	
	if (((window.location.href === "https://www.crclanguagelink.com.au/sys003.htm") && (!window.location.href.includes("item_id="))) || window.location.href.includes(baseA) ||(window.location.href === backUrl) || (window.location.href.includes("https://www.crclanguagelink.com.au/index.php?page_action=al_refresh")) ||  (window.location.href === "https://www.crclanguagelink.com.au/index.php?app_form_cd=SYS135") || ( window.location.href === "https://www.crclanguagelink.com.au/index.php") ) {
							
	//	alert("Country");
        CountryPrivateWork();
		
    }
	
	const editorUrl = "https://www.crclanguagelink.com.au/index.php?app_form_cd=fcls1046&prcs_defn_cd=&_template=default&_al_action_click=1&mode=edit&state_cd=&app_cd=&item_id=";
	
	const editorUrl2 = "https://www.crclanguagelink.com.au/index.php?app_form_cd=fcls1040&prcs_defn_cd=&_template=default&_al_action_click=1&mode=edit&state_cd=&app_cd=&item_id=";

	if ((window.location.href.toLowerCase().includes(editorUrl) || window.location.href.toLowerCase().includes(editorUrl2) )) {
//	if ( window.location.href.toLowerCase().includes(editorUrl) ) {
							
//		alert("trnEditorWork");
        trnEditorWork();
		
    }
	
	
	const trnCostingUrl = "https://www.crclanguagelink.com.au/index.php?app_form_cd=fcls1106&prcs_defn_cd=&_template=default&_al_action_click=1&mode=edit&state_cd=&app_cd=&item_id=";
	const  trnCostingUrl2 ="https://www.crclanguagelink.com.au/index.php?app_form_cd=fcls1106&item_id=";
	if ( (window.location.href.toLowerCase().includes(trnCostingUrl)) |( window.location.href.toLowerCase().includes(trnCostingUrl2) )) {
							
		//alert("trnCostingWork");
        trnCostingWork();
		
    }
	
	
	const cancelUrl = "https://www.crclanguagelink.com.au/index.php?app_form_cd=FCLS1028&prcs_defn_cd=&_template=default&_al_action_click=1&mode=edit&state_cd=&app_cd=&";
	if ( window.location.href.includes(cancelUrl) ) {
							
	//	alert("CancelWork");
        CancelChain();
		
    }
	
	
	
	
	
	const vendorProfile = "https://www.crclanguagelink.com.au/sys003.htm?app_form_cd=fcls1129&page_action=edit&_template=defailt&_action=_switch_tab&tab_cd=LS_RES&&page_action=view&mode=view&item_id=";
	if ( window.location.href.includes(vendorProfile) ) {
		highlightVendorDates();
	}	
	
	
	if (window.location.href.includes("custom=Attachments") || window.location.href.includes('https://www.crclanguagelink.com.au/index.php?app_form_cd=SYS033&_template=plain') || window.location.href === 'https://www.crclanguagelink.com.au/index.php') {
			 
			multiattach();
		}
	
  // Wait for the entire page to load before starting monitoring
  window.addEventListener('load', () => {
	   

	
	
	if (window.location.href.includes("showOL")) {
		 //alert("allocation");
        ExtractHeader(xpathToExtract);
		fixBulkphones();
    }
		
	
	
	
		

	const iframe = document.querySelector('iframe');
	iframe.addEventListener('load', () => {
			//	alert('loaded');
			
			
			const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
			
			// Step 4: Select the button inside the iframe using its XPath
			const zxpath = "/html/body/div[2]/div/form/div/div[3]/input[3]";
			const button = iframeDoc.evaluate(zxpath, iframeDoc, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
			//alert('clicked');
		//	if (button && window.location.href.includes("app_cd=FCLS&app_form_cd=FCLS1037&_template=logo&mode=view&item_id=")) {	


			const zxpath2 = "/html/body/div[2]/div/form/div/div[3]/input[2]";
		 
			const button2 = iframeDoc.evaluate(zxpath2, iframeDoc, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;


			if (button || button2) {
				//alert('clicked 1');
		//	if (button && 
				baseGUrl = baseGUrl.toLowerCase();
				
				urlViewTest  = 'app_cd=fcls&app_form_cd=fcls7066&_template=logo&&own_le_id=3&item_id=';
				urlViewTest2 = 'app_cd=fcls&app_form_cd=fcls7066&_template=logo&&own_le_id=3&mode=edit&item_id=';		
				urlViewTest3 = 'app_cd=fcls&app_form_cd=fcls1037&_template=logo&mode=view&item_id=';
				urlViewTest4 = 'app_form_cd=fcls7053&page_action=edit&_al_action_click=1&item_id=';
				urlViewTest5 = 'app_form_cd=fcls7050&item_id=';
				urlViewTest6 = 'app_cd=fcls&app_form_cd=fcls1034&_template=logo&mode=view&item_id=';
				
			 
				
		//		if (window.location.href.toLowerCase().includes("app_cd=fcls&app_form_cd=fcls1034&_template=logo&mode=view&item_id=")) { // cleintCancel
			 
		//		convertTelephoneThree();
		//		}
				
			//	if (baseGUrl.includes("showol") || baseGUrl.includes(urlViewTest)){
				if (baseGUrl.includes("showol") || baseGUrl.includes(urlViewTest6) || baseGUrl.includes(urlViewTest) || baseGUrl.includes(urlViewTest2) || baseGUrl.includes(urlViewTest3) || baseGUrl.includes(urlViewTest4) || baseGUrl.includes(urlViewTest5)){
					//alert('clicked 2');

					const updatedIframeDoc = iframe.contentDocument || iframe.contentWindow.document;
				//	alert(baseGUrl);
					
					if (updatedIframeDoc.body.innerHTML.includes('Contact person details') || updatedIframeDoc.body.innerHTML.includes('Casual client profile')){
						
						if (updatedIframeDoc.body.innerHTML.includes('Casual client profile')){
							 const xpaths = [
								  "/html/body/div[2]/div/form/div/fieldset/div[9]/div/input",
								  "/html/body/div[2]/div/form/div/fieldset/div[10]/div/input"
								];

								xpaths.forEach(xpath => {
								  const input = updatedIframeDoc.evaluate(xpath, updatedIframeDoc, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;

								  if (input && input.value) {
									const phone = input.value.trim();
									const telLink = document.createElement("a");
									telLink.href = `tel:${phone.replace(/\s+/g, '')}`;
									telLink.textContent = phone;
									//telLink.style.marginLeft = "10px";
									telLink.style.textDecoration = 'none';
									//input.parentNode.appendChild(telLink);
									input.parentNode.replaceChild(telLink, input);
									
								  }
								});
						} // else {
						
						tData = updatedIframeDoc.body.innerHTML;
						//alert(updatedIframeDoc.body.innerHTML);
						const phoneRegex = /(Telephone.+)/g;
						const phoneRegex2 = /(Mobile.+)/g;

						let match;
						const phoneNumbers = [];

						// Extract all matches
						while ((match = phoneRegex.exec(tData)) !== null) {
							phoneNumbers.push(match[1].trim()); // Extract and trim the number
							
											
											// Select the input field containing the telephone number
							const phoneInput = updatedIframeDoc.querySelector('input[name="LS_BookingInterpreting_e_intBD_e_venue_officer_phone_tx"]');

							if (phoneInput) {
								// Get the phone number from the input field
								const phoneNumber = phoneInput.value;

								// Create a hyperlink element
								const telLink = document.createElement('a');
								telLink.href = `tel:${phoneNumber}`;
								telLink.textContent = phoneNumber; // Set the display text as the phone number
								telLink.style.textDecoration = 'none'; // Optional: Remove underline

								// Replace the input field with the hyperlink
								const parentElement = phoneInput.parentNode;
								parentElement.replaceChild(telLink, phoneInput);

							} 

						}


						while ((match2 = phoneRegex2.exec(tData)) !== null) {
							//alert(match2[1].trim()); 
							const phoneInput2 = updatedIframeDoc.querySelector('input[name="LS_BookingInterpreting_e_intBD_e_venue_officer_mobile_tx"]');

							if (phoneInput2) {
							//	alert(phoneInput2);
								// Get the phone number from the input field
								const phoneNumber2 = phoneInput2.value;

								// Create a hyperlink element
								const telLink = document.createElement('a');
								telLink.href = `tel:${phoneNumber2}`;
								telLink.textContent = phoneNumber2; // Set the display text as the phone number
								telLink.style.textDecoration = 'none'; // Optional: Remove underline

								// Replace the input field with the hyperlink
								const parentElement = phoneInput2.parentNode;
								parentElement.replaceChild(telLink, phoneInput2);

							} 
							
						}	
					}
			//		if (phoneNumbers.length > 0) {
		//				console.log('Phone Numbers Found:', phoneNumbers);//
		//				alert(`Phone Numbers: ${phoneNumbers.join(', ')}`);
		//			} else {
		//				console.log('No phone numbers found!');
		//				alert('No phone numbers found!');
		//			}
				}
				
				
				
				
				
				
				
				
			}
	
	
	}); 	
		 
 
    startMonitoring();
	TRNHeader(xpathToExtract);
	PIC(xpathToExtract);
  }
  
  
  
  
  );
  
})();