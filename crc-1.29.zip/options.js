document.addEventListener('DOMContentLoaded', async function() {
    // Define default colors
    const defaultColors = {
        nesbText: "#FF0000",
        nesbBG: "#FFFFFF",
        suburbText: "#000000",
        suburbBG: "#66FFFF",
        clientText: "#CC0099",
        clientBG: "#FFFFFF"
    };

    // Retrieve saved settings from storage
    const result = await browser.storage.local.get([
        'enableNesb', 'cNesb', 'cNesbBG',
        'enableSuburb', 'cSuburb', 'cSuburbBG',
        'enableClient', 'cClient', 'cClientBG'
    ]);

    // NESB settings
    document.getElementById("enableNesb").checked = result.enableNesb !== undefined ? result.enableNesb : true;
    document.getElementById("cNesb").value = result.cNesb || defaultColors.nesbText;
    document.getElementById("cNesbBG").value = result.cNesbBG || defaultColors.nesbBG;

    // Suburb settings
    document.getElementById("enableSuburb").checked = result.enableSuburb !== undefined ? result.enableSuburb : true;
    document.getElementById("cSuburb").value = result.cSuburb || defaultColors.suburbText;
    document.getElementById("cSuburbBG").value = result.cSuburbBG || defaultColors.suburbBG;

    // Client settings
    document.getElementById("enableClient").checked = result.enableClient !== undefined ? result.enableClient : true;
    document.getElementById("cClient").value = result.cClient || defaultColors.clientText;
    document.getElementById("cClientBG").value = result.cClientBG || defaultColors.clientBG;

    // Event listener to save settings when form is submitted
    document.getElementById("settingsForm").addEventListener("submit", async function(event) {
        event.preventDefault();

        // NESB settings
        const enableNesb = document.getElementById("enableNesb").checked;
        const cNesb = document.getElementById("cNesb").value;
        const cNesbBG = document.getElementById("cNesbBG").value;

        // Suburb settings
        const enableSuburb = document.getElementById("enableSuburb").checked;
        const cSuburb = document.getElementById("cSuburb").value;
        const cSuburbBG = document.getElementById("cSuburbBG").value;

        // Client settings
        const enableClient = document.getElementById("enableClient").checked;
        const cClient = document.getElementById("cClient").value;
        const cClientBG = document.getElementById("cClientBG").value;

        // Save all settings in storage
        await browser.storage.local.set({
            enableNesb,
            cNesb,
            cNesbBG,
            enableSuburb,
            cSuburb,
            cSuburbBG,
            enableClient,
            cClient,
            cClientBG
        });

        alert("Settings saved successfully!");
    });

    // Reset button listeners to reset NESB colors
    document.getElementById("resetNesb").addEventListener("click", function() {
        document.getElementById("cNesb").value = defaultColors.nesbText;
        document.getElementById("cNesbBG").value = defaultColors.nesbBG;
    });

    // Reset button listener for Suburb colors
    document.getElementById("resetSuburb").addEventListener("click", function() {
        document.getElementById("cSuburb").value = defaultColors.suburbText;
        document.getElementById("cSuburbBG").value = defaultColors.suburbBG;
    });

    // Reset button listener for Client colors
    document.getElementById("resetClient").addEventListener("click", function() {
        document.getElementById("cClient").value = defaultColors.clientText;
        document.getElementById("cClientBG").value = defaultColors.clientBG;
    });
});
