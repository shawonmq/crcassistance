let logInterval = null;

document.addEventListener('DOMContentLoaded', () => {
  const clearBtn = document.getElementById("clearLogsBtn");
  const logContainer = document.getElementById("logContainer");

  // Always show the logs
  logContainer.style.display = "block";
  clearBtn.style.display = "inline-block";

  // Start displaying logs
  displayLogs();
  logInterval = setInterval(displayLogs, 1500);

  document.getElementById('openOptions').addEventListener('click', () => {
    if (typeof browser !== "undefined") {
      browser.runtime.openOptionsPage();
    } else if (typeof chrome !== "undefined") {
      chrome.runtime.openOptionsPage();
    } else {
      alert("Browser not supported.");
    }
  });

  clearBtn.addEventListener("click", () => {
    if (confirm("Are you sure you want to clear all logs?")) {
      browser.storage.local.remove("automationLogsX1").then(() => {
       // alert('cleared');
        logContainer.innerHTML = "<p>Logs cleared.</p>";
      });
    }
  });
});

function displayLogs() {
  browser.storage.local.get("automationLogsX1").then((result) => {
    const logs = result.automationLogsX1 || [];
    const container = document.getElementById("logContainer");
    container.innerHTML = "";

    if (logs.length === 0) {
      container.innerHTML = "<p>No logs yet.</p>";
      return;
    }

    const latestLogs = new Map();
    logs.forEach(log => latestLogs.set(log.itemId, log));

    const groupedLogs = {
      started: [],
      in_progress: [],
      completed: [],
      failed: []
    };

    latestLogs.forEach(log => {
      const statusKey = log.status.toLowerCase().replace(/\s+/g, "_");
      if (groupedLogs[statusKey]) groupedLogs[statusKey].push(log);
    });

    function createTable(title, logs, color, rowColor) {
      const section = document.createElement("div");
      section.innerHTML = `<h3 style="color:${color}; margin-top: 20px;">${title} (${logs.length})</h3>`;

      const table = document.createElement("table");
      table.style.width = "100%";
      table.style.borderCollapse = "collapse";
      table.style.marginBottom = "10px";
      table.style.textAlign = "left";
      table.style.fontFamily = "Arial, sans-serif";
      table.style.fontSize = "14px";

      const headerRow = document.createElement("tr");
      const headers = ["Item ID", "Tab ID", "Status", "Message", "Time"];

      headers.forEach(text => {
        const th = document.createElement("th");
        th.textContent = text;
        th.style.border = "1px solid #ccc";
        th.style.padding = "8px";
        th.style.backgroundColor = "#f2f2f2";
        th.style.fontWeight = "bold";
        headerRow.appendChild(th);
      });
      table.appendChild(headerRow);

      logs.forEach(log => {
        const row = document.createElement("tr");
        row.style.backgroundColor = rowColor;

        const cells = [
          log.itemId,
          log.tabId ?? "—",
          log.status.toUpperCase(),
          log.message,
          log.timestamp
        ];

        cells.forEach(text => {
          const td = document.createElement("td");
          td.textContent = text;
          td.style.padding = "8px";
          td.style.border = "1px solid #ddd";
          row.appendChild(td);
        });

        table.appendChild(row);
      });

      section.appendChild(table);
      container.appendChild(section);
    }

    createTable("Started", groupedLogs.started, "#888", "#f5f5f5");
    createTable("In Progress", groupedLogs.in_progress, "#007bff", "#e7f1ff");
    createTable("Completed", groupedLogs.completed, "green", "#e6ffe6");
    createTable("Failed", groupedLogs.failed, "red", "#ffe6e6");
  });
}

/*
function displayLogs() {
	//browser.storage.local.get(null).then(all => console.log("All storage keys:", all));

	
  browser.storage.local.get("automationLogsX1").then((result) => {
    const logs = result.automationLogsX1 || [];
    
	const container = document.getElementById("logContainer");
//	container.innerHTML = "<p>Updating</p>";
    container.innerHTML = "";
	
	//alert('displayLogs');
	
    if (logs.length === 0) {
      container.innerHTML = "<p>No logs yet.</p>";
      return;
    } else {
		
		
	}

    const latestLogs = new Map();
    logs.forEach(log => latestLogs.set(log.itemId, log));

    const groupedLogs = {
      started: [],
      in_progress: [],
      completed: [],
      failed: []
    };

    latestLogs.forEach(log => {
      const statusKey = log.status.toLowerCase().replace(/\s+/g, "_");
      if (groupedLogs[statusKey]) groupedLogs[statusKey].push(log);
    });

		
	function createTable(title, logs, color, rowColor) {
	  const section = document.createElement("div");
	  section.innerHTML = `<h3 style="color:${color}; margin-top: 20px;">${title} (${logs.length})</h3>`;

	  const table = document.createElement("table");
	  table.style.width = "100%";
	  table.style.borderCollapse = "collapse";
	  table.style.marginBottom = "10px";

	  const header = document.createElement("tr");
	  ["Item ID", "Tab ID", "Status", "Message", "Time"].forEach(text => {
		const th = document.createElement("th");
		th.textContent = text;
		th.style.borderBottom = "1px solid #ccc";
		th.style.padding = "6px";
		header.appendChild(th);
	  });
	  table.appendChild(header);

	  logs.forEach(log => {
		const row = document.createElement("tr");
		row.style.backgroundColor = rowColor;

		[log.itemId, log.tabId ?? "—", log.status.toUpperCase(), log.message, log.timestamp].forEach(text => {
		  const td = document.createElement("td");
		  td.textContent = text;
		  td.style.padding = "6px";
		  row.appendChild(td);
		});

		table.appendChild(row);
	  });

	  section.appendChild(table);
	  container.appendChild(section);
	}

    createTable("Started", groupedLogs.started, "#888", "#f5f5f5");
    createTable("In Progress", groupedLogs.in_progress, "#007bff", "#e7f1ff");
    createTable("Completed", groupedLogs.completed, "green", "#e6ffe6");
    createTable("Failed", groupedLogs.failed, "red", "#ffe6e6");
  });
}




*/

