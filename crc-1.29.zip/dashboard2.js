document.addEventListener('DOMContentLoaded', () => {
  const logContainer = document.getElementById("logContainer");

  document.getElementById("wtBtn").addEventListener("click", async () => {
    // Prompt for name
    
//	alert();
	
		if (confirm("Are you sure you want to withdraw yourself from the jobs?")) {
		  // User clicked Yes
		} else {
			return;
		  // User clicked No
		}



	/*
	
	const userName = window.prompt("Enter Target Panel Name to ALLOCATE:", "SOME PANEL");
    if (userName) {
      await browser.storage.local.set({ automationUserName: userName });
      console.log("Saved user name:", userName);
    } else {
      console.log("No name entered. Skipping name save.");
    }

    if (!userName) {
      console.log("User canceled or provided no input.");
      return;
    }
	*/
	
	const userNamePanel = window.prompt("Enter panel name who is currently allocated", "SOME PANEL");
    if (userNamePanel) {
      await browser.storage.local.set({ automationPanelName: userNamePanel });
      console.log("Saved user name:", userNamePanel);
    } else {
      console.log("No name entered. Skipping name save.");
    }

    if (!userNamePanel) {
      console.log("User canceled or provided no input.");
      return;
    }
	
    const userInput = window.prompt("Paste the text containing all TRN numbers to withdraw");
    if (!userInput) {
      console.log("User canceled or provided no input.");
      return;
    }












 //   const itemIds = Array.from(new Set(userInput.match(/\b3\d{6}\b/g)));
	const itemIds = Array.from(new Set(userInput.match(/\b3\d{6}(?=\s|TRN|$)/g)));

    if (itemIds.length === 0) {
      alert("No valid 7-digit item IDs starting with 3 were found.");
      return;
    }

    // Clear previous logs
    browser.storage.local.remove("automationLogsX1").then(() => {
      if (logContainer) {
        logContainer.innerHTML = "<p>Logs cleared.</p>";
      }
    });

    const logMessage = "Item logged and being opened";

    // Open each tab with a 2-second delay
    for (const id of itemIds) {
      //const url = `https://www.crclanguagelink.com.au/index.php?app_form_cd=FCLS1018&prcs_defn_cd=&_template=default&_al_action_click=1&mode=edit&state_cd=&app_cd=&item_id=${id}&`;
	  const url = `https://www.crclanguagelink.com.au/index.php?app_form_cd=FCLS1087&prcs_defn_cd=&_template=default&_al_action_click=1&mode=edit&state_cd=&app_cd=&item_id=${id}&`;

      // Open tab and wait for it to load
      const tab = await browser.tabs.create({ url });


		const tabId = tab.id;

		console.log("Created tab with ID:", tabId);
		/*
		// You already have the tabId now, no need to wait for onUpdated
		browser.runtime.sendMessage({
		  action: "logStatus",
		  itemId: id,
		  status: "started",
		  message: "Initiated",
		  timestamp: new Date().toISOString(),
		  tabId: tabId
		});

		await new Promise(resolve => setTimeout(resolve, 1500));
		
		browser.runtime.sendMessage({
		  action: "logStatus",
		  itemId: id,
		  status: "in_progress",
		  message: "Tab opened, waiting to load... ",
		  timestamp: new Date().toISOString(),
		  tabId: tabId
		});
		*/
	//*	
      browser.tabs.onUpdated.addListener(function listener(tabId, info) {
        if (tabId === tab.id && info.status === "complete") {
          // Log status to background
          browser.runtime.sendMessage({
            action: "logStatus",
            itemId: id,
            status: "started",
            message: logMessage,
            timestamp: new Date().toISOString(),
            tabId: tab.id
          });

          browser.tabs.onUpdated.removeListener(listener);

          // Tell content script to run automation
//          browser.tabs.sendMessage(tab.id, { action: "runAutomationStep" });
//		  browser.tabs.sendMessage(tab.id, { action: "runAutomationWithdrawStep" });
		  
		  browser.tabs.sendMessage(tab.id, {
			  action: "runSelfWithdrawal",
			  itemId: id,
			  tabId: tab.id
			  
			});

        }
      });

      // Wait 2 seconds before opening the next tab
      //await new Promise(resolve => setTimeout(resolve, 4000));
	  
    }
  });
  
  
  
   document.getElementById("wthallBtn").addEventListener("click", async () => {
    // Prompt for name
    
//	alert();
	
		if (confirm("Are you sure you want to withdraw the translator/s from the jobs?")) {
		  // User clicked Yes
		} else {
			return;
		  // User clicked No
		}

	
	
	const userName = window.prompt("Enter Target Panel Name to ALLOCATE:", "SOME PANEL");
    if (userName) {
      await browser.storage.local.set({ automationUserName: userName });
      console.log("Saved user name:", userName);
    } else {
      console.log("No name entered. Skipping name save.");
    }

    if (!userName) {
      console.log("User canceled or provided no input.");
      return;
    }
	
	if (confirm("Please ensure you enetered a VALID panel name who is available on optimized list")) {
		  // User clicked Yes
		} else {
			return;
		  // User clicked No
	}
	
  //  const userInput = window.prompt("Paste the text containing all TRN numbers to withdraw and ALLOCATE" , 'XXX');
	    const userInput = window.prompt("Paste the text containing all TRN numbers to withdraw and ALLOCATE" );

    if (!userInput) {
      console.log("User canceled or provided no input.");
      return;
    }

  // const itemIds = Array.from(new Set(userInput.match(/\b3\d{6}\b/g)));
	const itemIds = Array.from(new Set(userInput.match(/\b3\d{6}(?=\s|TRN|$)/g)));

    if (itemIds.length === 0) {
      alert("No valid 7-digit item IDs starting with 3 were found.");
      return;
    }

    // Clear previous logs
    browser.storage.local.remove("automationLogsX1").then(() => {
      if (logContainer) {
        logContainer.innerHTML = "<p>Logs cleared.</p>";
      }
    });

    const logMessage = "Item logged and being opened";

    // Open each tab with a 2-second delay
    for (const id of itemIds) {
      //const url = `https://www.crclanguagelink.com.au/index.php?app_form_cd=FCLS1018&prcs_defn_cd=&_template=default&_al_action_click=1&mode=edit&state_cd=&app_cd=&item_id=${id}&`;
	  const url = `https://www.crclanguagelink.com.au/index.php?app_form_cd=FCLS1018&prcs_defn_cd=&_template=default&_al_action_click=1&mode=edit&state_cd=&app_cd=&item_id=${id}&`;

      // Open tab and wait for it to load
      const tab = await browser.tabs.create({ url });


		const tabId = tab.id;

		console.log("Created tab with ID:", tabId);
		/*
		// You already have the tabId now, no need to wait for onUpdated
		browser.runtime.sendMessage({
		  action: "logStatus",
		  itemId: id,
		  status: "started",
		  message: "Initiated",
		  timestamp: new Date().toISOString(),
		  tabId: tabId
		});

		await new Promise(resolve => setTimeout(resolve, 1500));
		
		browser.runtime.sendMessage({
		  action: "logStatus",
		  itemId: id,
		  status: "in_progress",
		  message: "Tab opened, waiting to load... ",
		  timestamp: new Date().toISOString(),
		  tabId: tabId
		});
		*/
	//*	
      browser.tabs.onUpdated.addListener(function listener(tabId, info) {
        if (tabId === tab.id && info.status === "complete") {
          // Log status to background
          browser.runtime.sendMessage({
            action: "logStatus",
            itemId: id,
            status: "started",
            message: logMessage,
            timestamp: new Date().toISOString(),
            tabId: tab.id
          });

          browser.tabs.onUpdated.removeListener(listener);

          // Tell content script to run automation
//          browser.tabs.sendMessage(tab.id, { action: "runAutomationStep" });
//		  browser.tabs.sendMessage(tab.id, { action: "runAutomationWithdrawStep" });
		  
		  browser.tabs.sendMessage(tab.id, {
			  action: "runAutomationStep",
			  itemId: id,
			  tabId: tab.id
			  
			});

        }
      });

      // Wait 2 seconds before opening the next tab
      //await new Promise(resolve => setTimeout(resolve, 4000));
	  
    }
  });
  
  
  
  
});


function logAutomationStatus({ itemId, status, message, tabId = null }) {
  browser.runtime.sendMessage({
    action: "logStatus",
    itemId,
    status,
    message,
    timestamp: new Date().toISOString(),
    tabId
  });
}
