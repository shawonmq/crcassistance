// Listen for the browser action icon click
browser.browserAction.onClicked.addListener(() => {
  // Open the options page
  //browser.runtime.openOptionsPage();
	//alert('d');
  browser.tabs.create({
    url: browser.runtime.getURL("dashboard.html")
  });
});




browser.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "getMyTabId") {
    sendResponse({ tabId: sender.tab.id });
  }
});


browser.runtime.onMessage.addListener((message, sender) => {
  if (message.action === "closeThisTab" && sender.tab?.id) {
    browser.tabs.remove(sender.tab.id);
  }
});


/*


browser.runtime.onMessage.addListener((message, sender) => {
  if (message.action === "logStatus") {
    browser.storage.local.get("automationLogsX1").then((result) => {
      const logs = result.automationLogsX1 || [];
      logs.push({
        itemId: message.itemId,
        status: message.status,
        message: message.message,
        timestamp: message.timestamp
      });
      browser.storage.local.set({ automationLogsX1: logs });
    });
  }
});






browser.runtime.onMessage.addListener((message, sender) => {
  if (message.action === "logStatus") {
	const tabId = message.tabId ?? null; // use message.tabId if provided, else null
    browser.storage.local.get("automationLogsX1").then((result) => {
      const logs = result.automationLogsX1 || [];
      logs.push({
        itemId: message.itemId,
        status: message.status,
        message: message.message,
        timestamp: message.timestamp,
		tabId: tabId // log the tab ID here
      });
      browser.storage.local.set({ automationLogsX1: logs });
    });
  }
});

*/



browser.runtime.onMessage.addListener((message, sender) => {
  if (message.action === "logStatus") {
    const tabId = message.tabId ?? null;

    browser.storage.local.get("automationLogsX1").then((result) => {
      let logs = result.automationLogsX1 || [];

      // Remove any existing entry with the same itemId
      logs = logs.filter(log => log.itemId !== message.itemId);

      // Push the new log entry
      logs.push({
        itemId: message.itemId,
        status: message.status,
        message: message.message,
        timestamp: message.timestamp,
        tabId: tabId
      });

      // Save back to storage
      browser.storage.local.set({ automationLogsX1: logs });
    });
  }
});


