let logInterval = null;

// move to global scope
let toggleBtn = null;
let statusText = null;

document.addEventListener('DOMContentLoaded', async () => {
    toggleBtn = document.getElementById('toggleBasicBtn');
    statusText = document.getElementById('basicStatusText');

    const clearBtn = document.getElementById("clearLogsBtn");
    const logContainer = document.getElementById("logContainer");

    // Always show the logs
    logContainer.style.display = "block";
    clearBtn.style.display = "inline-block";

    // Start displaying logs
    displayLogs();
    logInterval = setInterval(displayLogs, 5000);

   


    document.getElementById('openOptions').addEventListener('click', () => {
        if (typeof browser !== "undefined") {
            browser.runtime.openOptionsPage();
        } else if (typeof chrome !== "undefined") {
            chrome.runtime.openOptionsPage();
        } else {
            alert("Browser not supported.");
        }
    });

    clearBtn.addEventListener("click", () => {
        if (confirm("Are you sure you want to clear all logs?")) {
			
			 updateActionStatus("Cleared log");
            browser.storage.local.remove("automationLogsX1").then(() => {
                logContainer.innerHTML = "<p>Logs cleared.</p>";
            });
        }
    });

    
	
	
});


function updateActionStatus(message) {
    const statusDiv = document.getElementById("logContainerTime");
    const timestamp = new Date().toLocaleString();
    
    statusDiv.style.display = "block"; // make it visible
    statusDiv.innerHTML = `<p>${message} - ${timestamp}</p>`;
}


function displayLogs() {
    browser.storage.local.get("automationLogsX1").then((result) => {
        const logs = result.automationLogsX1 || [];
        const container = document.getElementById("logContainer");
        container.innerHTML = "";

        if (logs.length === 0) {
            container.innerHTML = "<p>No logs yet.</p>";
            return;
        }

        const latestLogs = new Map();
        logs.forEach(log => latestLogs.set(log.itemId, log));

        const groupedLogs = {
            started: [],
            in_progress: [],
            completed: [],
            failed: []
        };

        latestLogs.forEach(log => {
            const statusKey = log.status.toLowerCase().replace(/\s+/g, "_");
            if (groupedLogs[statusKey]) groupedLogs[statusKey].push(log);
        });

        function createTable(title, logs, color, rowColor) {
            const section = document.createElement("div");
            section.innerHTML = `<h3 style="color:${color}; margin-top: 20px;">${title} (${logs.length})</h3>`;

            const table = document.createElement("table");
            table.style.width = "100%";
            table.style.borderCollapse = "collapse";
            table.style.marginBottom = "10px";
            table.style.textAlign = "left";
            table.style.fontFamily = "Arial, sans-serif";
            table.style.fontSize = "14px";

            const headerRow = document.createElement("tr");
            const headers = ["Item ID", "Tab ID", "Status", "Message", "Time"];

            headers.forEach(text => {
                const th = document.createElement("th");
                th.textContent = text;
                th.style.border = "1px solid #ccc";
                th.style.padding = "8px";
                th.style.backgroundColor = "#f2f2f2";
                th.style.fontWeight = "bold";
                headerRow.appendChild(th);
            });
            table.appendChild(headerRow);

            logs.forEach(log => {
                const row = document.createElement("tr");
                row.style.backgroundColor = rowColor;

                const cells = [
                    log.itemId,
                    log.tabId ?? "—",
                    log.status.toUpperCase(),
                    log.message,
                    log.timestamp
                ];

         //       cells.forEach(text => {
         //           const td = document.createElement("td");
         //           td.textContent = text;
         //           td.style.padding = "8px";
         //           td.style.border = "1px solid #ddd";
         //           row.appendChild(td);
        //        });

				cells.forEach((text, index) => {
					const td = document.createElement("td");
					td.style.padding = "8px";
					td.style.border = "1px solid #ddd";

					// Make Item ID (index 0) a clickable hyperlink
					if (index === 0 && text) {
						const link = document.createElement("a");
						link.textContent = text;
						link.href = `https://www.crclanguagelink.com.au/index.php?app_cd=FCLS&app_form_cd=FCLS1034&_template=logo&mode=view&item_id=${text}`; 
						link.target = "_blank"; // open in new tab
						link.style.color = "#007bff";
						link.style.textDecoration = "none";
						link.onmouseover = () => (link.style.textDecoration = "underline");
						link.onmouseout = () => (link.style.textDecoration = "none");
						td.appendChild(link);
					} else {
						td.textContent = text;
					}

					row.appendChild(td);
				});
                table.appendChild(row);
            });

            section.appendChild(table);
            container.appendChild(section);
        }

        createTable("Started", groupedLogs.started, "#888", "#f5f5f5");
        createTable("In Progress", groupedLogs.in_progress, "#007bff", "#e7f1ff");
        createTable("Completed", groupedLogs.completed, "green", "#e6ffe6");
        createTable("Failed", groupedLogs.failed, "red", "#ffe6e6");
    });
}
