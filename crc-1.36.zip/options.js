document.addEventListener('DOMContentLoaded', async function() {
    // Define default colors
    const defaultColors = {
        nesbText: "#FF0000",
        nesbBG: "#FFFFFF",
        suburbText: "#000000",
        suburbBG: "#66FFFF",
        clientText: "#CC0099",
        clientBG: "#FFFFFF",
        HeaderBG: "#A9A9A9",
        HeaderText: "#000000"
    };

    // Retrieve saved settings from storage
    const result = await browser.storage.local.get([
        'enableNesb', 'cNesb', 'cNesbBG',
        'enableSuburb', 'cSuburb', 'cSuburbBG',
        'enableClient', 'cClient', 'cClientBG',
        'enablePrivacy', 'cHeaderTxt', 'cHeaderBG' ,
		'customTextNotes'
    ]);

   // if (result.customTextNotes) document.getElementById("customTextNotes").value = result.customTextNotes;

	document.getElementById("customTextNotes").value = result.customTextNotes ?? "";

    // Helper: update preview box colors
    const updatePreview = (textId, bgId, previewId) => {
        document.getElementById(previewId).style.color = document.getElementById(textId).value;
        document.getElementById(previewId).style.backgroundColor = document.getElementById(bgId).value;
    };

    // Load saved or default values + show previews
    document.getElementById("enableNesb").checked = result.enableNesb ?? true;
    document.getElementById("cNesb").value = result.cNesb || defaultColors.nesbText;
    document.getElementById("cNesbBG").value = result.cNesbBG || defaultColors.nesbBG;
    updatePreview("cNesb", "cNesbBG", "previewNesb");

    document.getElementById("enableSuburb").checked = result.enableSuburb ?? true;
    document.getElementById("cSuburb").value = result.cSuburb || defaultColors.suburbText;
    document.getElementById("cSuburbBG").value = result.cSuburbBG || defaultColors.suburbBG;
    updatePreview("cSuburb", "cSuburbBG", "previewSuburb");

    document.getElementById("enableClient").checked = result.enableClient ?? true;
    document.getElementById("cClient").value = result.cClient || defaultColors.clientText;
    document.getElementById("cClientBG").value = result.cClientBG || defaultColors.clientBG;
    updatePreview("cClient", "cClientBG", "previewClient");

    document.getElementById("enablePrivacy").checked = result.enablePrivacy ?? true;
    document.getElementById("cHeaderTxt").value = result.cHeaderTxt || defaultColors.HeaderText;
    document.getElementById("cHeaderBG").value = result.cHeaderBG || defaultColors.HeaderBG;
    updatePreview("cHeaderTxt", "cHeaderBG", "previewHeader");

    // Live preview on color pick (text & bg) - listen for input & change events
    // Live preview update for all sections (cross-browser, robust)
		[
		  ["cNesb","cNesbBG","previewNesb"],
		  ["cSuburb","cSuburbBG","previewSuburb"],
		  ["cClient","cClientBG","previewClient"],
		  ["cHeaderTxt","cHeaderBG","previewHeader"]
		].forEach(([textId, bgId, previewId]) => {
		  ["input","change"].forEach(eventName => {
			document.getElementById(textId).addEventListener(eventName, () =>
			  updatePreview(textId, bgId, previewId)
			);
			document.getElementById(bgId).addEventListener(eventName, () =>
			  updatePreview(textId, bgId, previewId)
			);
		  });
		});


    // Save settings
    document.getElementById("settingsForm").addEventListener("submit", async function(event) {
        event.preventDefault();

        const settings = {
            enableNesb: document.getElementById("enableNesb").checked,
            cNesb: document.getElementById("cNesb").value,
            cNesbBG: document.getElementById("cNesbBG").value,

            enableSuburb: document.getElementById("enableSuburb").checked,
            cSuburb: document.getElementById("cSuburb").value,
            cSuburbBG: document.getElementById("cSuburbBG").value,

            enableClient: document.getElementById("enableClient").checked,
            cClient: document.getElementById("cClient").value,
            cClientBG: document.getElementById("cClientBG").value,

            enablePrivacy: document.getElementById("enablePrivacy").checked,
            cHeaderTxt: document.getElementById("cHeaderTxt").value,
            cHeaderBG: document.getElementById("cHeaderBG").value,
			
			customTextNotes: document.getElementById("customTextNotes").value
			
        };

        await browser.storage.local.set(settings);
        alert("Settings saved successfully!");
    });

    // Reset buttons
    document.getElementById("resetNesb").addEventListener("click", () => {
        document.getElementById("cNesb").value = defaultColors.nesbText;
        document.getElementById("cNesbBG").value = defaultColors.nesbBG;
        updatePreview("cNesb", "cNesbBG", "previewNesb");
    });

    document.getElementById("resetSuburb").addEventListener("click", () => {
        document.getElementById("cSuburb").value = defaultColors.suburbText;
        document.getElementById("cSuburbBG").value = defaultColors.suburbBG;
        updatePreview("cSuburb", "cSuburbBG", "previewSuburb");
    });

    document.getElementById("resetClient").addEventListener("click", () => {
        document.getElementById("cClient").value = defaultColors.clientText;
        document.getElementById("cClientBG").value = defaultColors.clientBG;
        updatePreview("cClient", "cClientBG", "previewClient");
    });

    document.getElementById("resetHeader").addEventListener("click", () => {
        document.getElementById("cHeaderTxt").value = defaultColors.HeaderText;
        document.getElementById("cHeaderBG").value = defaultColors.HeaderBG;
        updatePreview("cHeaderTxt", "cHeaderBG", "previewHeader");
    });
});
