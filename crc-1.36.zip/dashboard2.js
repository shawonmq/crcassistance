document.addEventListener('DOMContentLoaded', () => {
  const logContainer = document.getElementById("logContainer");

  document.getElementById("wtBtn").addEventListener("click", async () => {
	  
	   try {
		   
		   		   /// Withdraw Translator
		   
		    let timeOut = 2500;	  
			let loopCounter = 0;
			let bypassed = 0;
		   
	      const userInput = await showCustomModal2();
		  
				  
				  
			if (!userInput.currentPanelName) {
			  alert("Current Panel Name Missing - Exiting");
			  return;
			}

			 
			

			if (!userInput.freeText) {
			  alert("TRN numbers missing");
			  return;
			}

			if (userInput.freeText.includes("bypass")) {
			  bypassed = 1;
			  
			}
			
//			const itemIds = Array.from(new Set(userInput.freeText.match(/\b3\d{6}(?=\s|TRN|$)/g)));
			const itemIds = Array.from(new Set(userInput.freeText.match(/\b3\d{6}(?=[\s,.;:]|TRN|$)/g)));

			if (itemIds.length === 0) {
			  alert("No valid 7-digit item IDs starting with 3 were found.");
			  return;
			}

			let currentPanelName = userInput.currentPanelName.trim();
		
			await browser.storage.local.set({
			  automationPanelName: currentPanelName
			  
			});
				
			// Clear previous logs
			browser.storage.local.remove("automationLogsX1").then(() => {
			  if (logContainer) {
				logContainer.innerHTML = "<p>Logs cleared.</p>";
			  }
			});

			const logMessage = "Item logged and being opened";
			updateActionStatus("Withdraw to next panel process initiated");
			
			
			// Open each tab with a 2-second delay
			for (const id of itemIds) {
				
				loopCounter = loopCounter + 1;
			  //const url = `https://www.crclanguagelink.com.au/index.php?app_form_cd=FCLS1018&prcs_defn_cd=&_template=default&_al_action_click=1&mode=edit&state_cd=&app_cd=&item_id=${id}&`;
			  const url = `https://www.crclanguagelink.com.au/index.php?app_form_cd=FCLS1087&prcs_defn_cd=&_template=default&_al_action_click=1&mode=edit&state_cd=&app_cd=&item_id=${id}&bypass`;

			  // Open tab and wait for it to load
			  const tab = await browser.tabs.create({ url , active: false});


				const tabId = tab.id;

				console.log("Created tab with ID:", tabId);
			
			  browser.tabs.onUpdated.addListener(function listener(tabId, info) {
				if (tabId === tab.id && info.status === "complete") {
				  // Log status to background
				  browser.runtime.sendMessage({
					action: "logStatus",
					itemId: id,
					status: "started",
					message: logMessage,
					timestamp: new Date().toISOString(),
					tabId: tab.id
				  });

				  browser.tabs.onUpdated.removeListener(listener);

				  // Tell content script to run automation
		//          browser.tabs.sendMessage(tab.id, { action: "runAutomationStep" });
		//		  browser.tabs.sendMessage(tab.id, { action: "runAutomationWithdrawStep" });
				  
				  browser.tabs.sendMessage(tab.id, {
					  action: "runSelfWithdrawal",
					  itemId: id,
					  tabId: tab.id
					  
					});

				}
			  });

			if (loopCounter === 5) {
					timeOut = 120000; // every 5th loop, wait 30s
					loopCounter = 0;
			} else{
				timeOut = 2500;
			}
			
					
				if (bypassed == 1){
					timeOut = 2500;
					//alert('bypass');
				}

		
			  // Wait 2 seconds before opening the next tab
			  await new Promise(resolve => setTimeout(resolve, timeOut));
			  
			}
		
			
	

		} catch (e) {
			console.log("Modal cancelled or error:", e);
			return;
	  }
	
	  
	  
  });
  
  
  document.getElementById("wthallBtn").addEventListener("click", async () => {
  try {
	  
	  /// Withdraw Translator and allocate to panel
	  
	let timeOut = 2500;	  
	let loopCounter = 0;
	let bypassed = 0;
	  
   

    const userInput = await showCustomModal();
    console.log("User input:", userInput);

    // Save panel names & dates
    

	if (!userInput.currentPanelName) {
      alert("Current Panel Name Missing - Exiting");
      return;
    }

	if (!userInput.targetPanelName) {
      alert("Target Panel Name Missing - Exiting");
      return;
    }
	
	

    if (!userInput.freeText) {
      alert("TRN numbers missing");
      return;
    }


	
	if (userInput.freeText.includes("bypass")) {
	  bypassed = 1;
	  
	}
	
    //const itemIds = Array.from(new Set(userInput.freeText.match(/\b3\d{6}(?=\s|TRN|$)/g)));
	const itemIds = Array.from(new Set(userInput.freeText.match(/\b3\d{6}(?=[\s,.;:]|TRN|$)/g)));
    if (itemIds.length === 0) {
      alert("No valid 7-digit item IDs starting with 3 were found.");
      return;
    }

	let currentPanelName = userInput.currentPanelName.trim();
    let targetPanelName = userInput.targetPanelName.trim();
    let dueFromTranslator = userInput.dueFromTranslator.trim();
    let dueToClient = userInput.dueToClient.trim();

	dueFromTranslator = cleanAndValidateDate(dueFromTranslator);
	
    if (dueFromTranslator === null) {
      alert("Invalid date format in 'Due from Translator'. Use dd/mm/yyyy.");
      return;
    }

    dueToClient = cleanAndValidateDate(dueToClient);
    if (dueToClient === null) {
      alert("Invalid date format in 'Due to Client'. Use dd/mm/yyyy.");
      return;
    }
	
	//alert(dueFromTranslator);

	await browser.storage.local.set({
      automationPanelName: currentPanelName,
      automationUserName: targetPanelName,
      automationDueFromTranslator: dueFromTranslator,
      automationDueToClient: dueToClient
    });




 

    // Clear previous logs
    browser.storage.local.remove("automationLogsX1").then(() => {
      if (logContainer) {
        logContainer.innerHTML = "<p>Logs cleared.</p>";
      }
    });

    const logMessage = "Item logged and being opened";
	
	    
	updateActionStatus("Withdraw & Allocate process initiated");

    // Open each tab with a 2-second delay
    for (const id of itemIds) {
		
		loopCounter = loopCounter + 1;
		
      //const url = `https://www.crclanguagelink.com.au/index.php?app_form_cd=FCLS1018&prcs_defn_cd=&_template=default&_al_action_click=1&mode=edit&state_cd=&app_cd=&item_id=${id}&`;
	  const url = `https://www.crclanguagelink.com.au/index.php?app_form_cd=FCLS1018&prcs_defn_cd=&_template=default&_al_action_click=1&mode=edit&state_cd=&app_cd=&item_id=${id}&bypass`;

      // Open tab and wait for it to load
      const tab = await browser.tabs.create({ url, active: false });


		const tabId = tab.id;

		console.log("Created tab with ID:", tabId);
		/*
		// You already have the tabId now, no need to wait for onUpdated
		browser.runtime.sendMessage({
		  action: "logStatus",
		  itemId: id,
		  status: "started",
		  message: "Initiated",
		  timestamp: new Date().toISOString(),
		  tabId: tabId
		});

		await new Promise(resolve => setTimeout(resolve, 1500));
		
		browser.runtime.sendMessage({
		  action: "logStatus",
		  itemId: id,
		  status: "in_progress",
		  message: "Tab opened, waiting to load... ",
		  timestamp: new Date().toISOString(),
		  tabId: tabId
		});
		*/
	//*	
      browser.tabs.onUpdated.addListener(function listener(tabId, info) {
        if (tabId === tab.id && info.status === "complete") {
          // Log status to background
          browser.runtime.sendMessage({
            action: "logStatus",
            itemId: id,
            status: "started",
            message: logMessage,
            timestamp: new Date().toISOString(),
            tabId: tab.id
          });

          browser.tabs.onUpdated.removeListener(listener);

          // Tell content script to run automation
//          browser.tabs.sendMessage(tab.id, { action: "runAutomationStep" });
//		  browser.tabs.sendMessage(tab.id, { action: "runAutomationWithdrawStep" });
		  
		  browser.tabs.sendMessage(tab.id, {
			  action: "runAutomationStep",
			  itemId: id,
			  tabId: tab.id
			  
			});

        }
      });

			if (loopCounter === 5) {
					timeOut = 60000; // every 5th loop, wait 30s
					loopCounter = 0;
			} else {
			
				timeOut = 2500;
			}

		
				if (bypassed == 1){
					timeOut = 2500;
					//alert('bypass');
				}


      // Wait 2 seconds before opening the next tab
      await new Promise(resolve => setTimeout(resolve, timeOut));
	  
    }


    // proceed with your existing logic to open tabs, etc.

  } catch (e) {
    console.log("Modal cancelled or error:", e);
    return;
  }
});

  
   document.getElementById("BtnSourceCheck").addEventListener("click", async () => {
	   
	   
    const userInput = window.prompt("Paste the text containing all TRN numbers to check source availabilty");
    if (!userInput) {
      console.log("User canceled or provided no input.");
      return;
    }

	

//   const itemIds = Array.from(new Set(userInput.match(/\b3\d{6}\b/g)));
	//const itemIds = Array.from(new Set(userInput.match(/\b3\d{6}(?=\s|TRN|$)/g)));
	const itemIds = Array.from(new Set(userInput.match(/\b3\d{6}(?=[\s,.;:]|TRN|$)/g)));

	
    if (itemIds.length === 0) {
      alert("No valid 7-digit item IDs starting with 3 were found.");
      return;
    }

    // Clear previous logs
    browser.storage.local.remove("automationLogsX1").then(() => {
      if (logContainer) {
        logContainer.innerHTML = "<p>Logs cleared.</p>";
      }
    });

    const logMessage = "Item logged and being opened";

    updateActionStatus("Source check initiated");

    // Open each tab with a 2-second delay
    for (const id of itemIds) {
      //const url = `https://www.crclanguagelink.com.au/index.php?app_form_cd=FCLS1018&prcs_defn_cd=&_template=default&_al_action_click=1&mode=edit&state_cd=&app_cd=&item_id=${id}&`;
	  const url = `https://www.crclanguagelink.com.au/index.php?app_form_cd=FCLS1018&prcs_defn_cd=&_template=default&_al_action_click=1&mode=edit&state_cd=&app_cd=&item_id=${id}&bypass`;

      // Open tab and wait for it to load
      const tab = await browser.tabs.create({ url , active: false});


		const tabId = tab.id;

		console.log("Created tab with ID:", tabId);
	
      browser.tabs.onUpdated.addListener(function listener(tabId, info) {
        if (tabId === tab.id && info.status === "complete") {
          // Log status to background
          browser.runtime.sendMessage({
            action: "logStatus",
            itemId: id,
            status: "started",
            message: logMessage,
            timestamp: new Date().toISOString(),
            tabId: tab.id
          });

          browser.tabs.onUpdated.removeListener(listener);
 
		  browser.tabs.sendMessage(tab.id, {
			  action: "runSourceCheck",
			  itemId: id,
			  tabId: tab.id
			  
			});

        }
      });

      // Wait 2 seconds before opening the next tab
      //await new Promise(resolve => setTimeout(resolve, 4000));
	  
    }
	   
   });
  
});


function logAutomationStatus({ itemId, status, message, tabId = null }) {
  browser.runtime.sendMessage({
    action: "logStatus",
    itemId,
    status,
    message,
    timestamp: new Date().toISOString(),
    tabId
  });
}


function showCustomModal() {
  return new Promise((resolve, reject) => {
    const modal = document.getElementById("customModal");
    modal.style.display = "block";

    const okBtn = document.getElementById("modalOkBtn");
    const cancelBtn = document.getElementById("modalCancelBtn");

    // Cleanup old listeners
    okBtn.onclick = () => {
      const data = {
        currentPanelName: document.getElementById("currentPanelName").value.trim(),
        targetPanelName: document.getElementById("targetPanelName").value.trim(),
        dueFromTranslator: document.getElementById("dueFromTranslator").value.trim(),
        dueToClient: document.getElementById("dueToClient").value.trim(),
        freeText: document.getElementById("freeTextInput").value.trim()
      };
      modal.style.display = "none";
      resolve(data);
    };

    cancelBtn.onclick = () => {
      modal.style.display = "none";
      reject(new Error("User cancelled"));
    };
  });
}



function cleanAndValidateDate(input) {
  if (!input) return "";  // allow blank

  input = input.replace(/\s+/g, '').replace(/\./g, '/');  // remove spaces & replace . with /

  const regex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = input.match(regex);
  if (!match) return null;

  const [ , dd, mm, yyyy ] = match;
  const date = new Date(`${yyyy}-${mm}-${dd}`);

  // Check if it's a real date
  if (date.getDate() != parseInt(dd) || (date.getMonth() + 1) != parseInt(mm) || date.getFullYear() != parseInt(yyyy)) {
    return null;
  }

  return `${dd}/${mm}/${yyyy}`;  // return cleaned, validated date
}


function showCustomModal2() {
  return new Promise((resolve, reject) => {
    const modal = document.getElementById("customModal2");
    modal.style.display = "block";

    const okBtn = document.getElementById("modalOkBtn2");
    const cancelBtn = document.getElementById("modalCancelBtn2");

    const handleOk = () => {
      const data = {
        currentPanelName: document.getElementById("currentPanelName2").value.trim(),
        freeText: document.getElementById("freeTextInput2").value.trim()
      };
      modal.style.display = "none";
      resolve(data);
    };

    const handleCancel = () => {
      modal.style.display = "none";
      reject(new Error("User cancelled"));
    };

    okBtn.addEventListener("click", handleOk, { once: true });
    cancelBtn.addEventListener("click", handleCancel, { once: true });
  });
}
