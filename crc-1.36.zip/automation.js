let alertCount = 0;
//const basePosition = 20;
//const rightPosition = 20;
const basePosition = Math.floor(Math.random() * (450 - 150 + 1)) + 150;
const rightPosition = Math.floor(Math.random() * (350 - 50 + 1)) + 50;



function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function waitforme() {
  console.log("Start wait");
  await sleep(2500);
  console.log("End wait");
}




function highlightElement(element) {
    if (element) {
      element.style.backgroundColor = 'cyan'; // Apply highlighting style
    }
  }


function showNotificationBootstrapNotify(message) {
	
	let tOut;
		if (window.location.href.toLowerCase().includes("&ol_order_nr=")) {
			tOut = 500;
		} else {
			tOut = 2000;
		}

	// Delay the creation of the alert by 3 seconds
	setTimeout(() => {
		const alertDiv = document.createElement('div');
		alertDiv.classList.add('custom-alert');

		// Array of colors
		const colors = [
			'#4DBA67', '#FF6F61', '#6A5ACD', '#FF69B4', '#40E0D0', '#4682B4', '#D2691E', 
			'#20B2AA', '#FF4500', '#8A2BE2', '#DC143C', '#9932CC', '#B22222', '#008080', 
			'#800080', '#CD5C5C', '#4169E1', '#FF6347', '#7B68EE', '#8B4513'
		];

		// Styles
		const styles = ['style-1'];

		// Randomly select a color and style
		const randomColor = colors[Math.floor(Math.random() * colors.length)];
		const randomStyle = styles[Math.floor(Math.random() * styles.length)];

		// Set the content, random style, and random color of the alert
		alertDiv.innerText = message;
		alertDiv.style.backgroundColor = randomColor;
		alertDiv.classList.add(randomStyle);

		// Set the position of the alert based on alertCount
		const offset = alertCount * 70; // Offset each subsequent alert by 70px
		alertDiv.style.top = `${basePosition + alertCount * 60}px`;
		alertDiv.style.right = `${rightPosition}px`; // Fixed right position

		// Append the alert to the body
		document.body.appendChild(alertDiv);

		// Set timeout duration based on URL condition
		
		// Automatically remove the alert after the specified timeout
		setTimeout(() => {
			alertDiv.style.opacity = '0'; // Fade out the alert
			setTimeout(() => alertDiv.remove(), tOut); // Remove the element after fade-out
		}, 7000);

		// Increment alert count for the next alert
		alertCount++;
	}, tOut); // Delay of 3 seconds
}







async function getMessageByTabId(tabIdToFind) {
  const result = await browser.storage.local.get("automationLogsX1");
  const logs = result.automationLogsX1 || [];
  const matchingLog = logs.find(log => log.tabId === tabIdToFind);
  return matchingLog ? matchingLog.message : null;
}

async function getItemIDByTabId(tabIdToFind) {
  const result = await browser.storage.local.get("automationLogsX1");
  const logs = result.automationLogsX1 || [];
  //const matchingLog = logs.find(log => log.tabId === tabIdToFind);
  const matchingLog = logs.find(log => Number(log.tabId) === Number(tabIdToFind));

  return matchingLog ? matchingLog.itemId : null;
}





async function getTabIdByItemId(itemIdToFind) {
  try {
    const result = await browser.storage.local.get("automationLogsX1");
    const logs = result.automationLogsX1 || [];

    // Find the latest matching log by itemId
    const matchingLog = logs.reverse().find(log => log.itemId === itemIdToFind);

    return matchingLog ? matchingLog.tabId : null;
  } catch (error) {
    console.error("Error fetching tab ID:", error);
    return null;
  }
}




async function getCurrentTabId(timeout = 3000) {
  return new Promise((resolve) => {
    let resolved = false;

    // Try to get the tab ID from background
    browser.runtime.sendMessage({ action: "getMyTabId" }).then(response => {
      if (!resolved) {
        resolved = true;
        resolve(response.tabId);
      }
    }).catch(() => {
      if (!resolved) {
        resolved = true;
        resolve(null);
      }
    });

    // Set timeout fallback
    setTimeout(() => {
      if (!resolved) {
        resolved = true;
        resolve(null); // timeout
      }
    }, timeout);
  });
}






function updateLog(itemId, status, message = "", tabId = null) {
  const now = new Date();
  const timestamp = now.toLocaleString("en-AU", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit",
    hour12: true
  });
  
  
  
  if (tabId !== null) {
    tabId = tabId;
  }else{
	  tabId = "";
  }

  const logData = {
    action: "logStatus",
    itemId,
    status,
    message,
    timestamp,
	tabId
  };


  browser.runtime.sendMessage(logData);
}



function waitForXPath(xpath, timeout = 5000, interval = 200) {
  return new Promise((resolve, reject) => {
    const startTime = Date.now();

    const check = () => {
      const element = getElementByXPath(xpath);
      if (element) {
        resolve(element);
      } else if (Date.now() - startTime > timeout) {
        reject(new Error("Timeout waiting for element: " + xpath));
      } else {
        setTimeout(check, interval);
      }
    };

    check();
  });
}



function getItemIdFromURL() {
  const url = new URL(window.location.href);
  return url.searchParams.get("item_id") || "unknown";
}



function runAllocationStep(itemId, tabId) {
	 

  updateLog(itemId, "in_progress", "Running allocation step...",tabId);


	var headPath = '//*[@id="sys_desc"]';
	  
	 const headerType = getElementByXPath(headPath, document);
	 
	/*  -- to fix  this before dispatch  
	 
	if (headerType && !headerType.textContent.includes('Manual Allocation')){
		
		 updateLog(itemId, "failed", "Manual withdrawal may have failed.", tabId);
	  browser.runtime.sendMessage({ action: "closeThisTab" });
	  return;
		
	}
	/*/

  // Search input field
  const searchTextEntry = getElementByXPath('//*[@id="FCLS7051_srch_name_tx"]');
  




	if (searchTextEntry) {
		
		
		browser.storage.local.get("automationUserName").then(result => {
			  const name = result.automationUserName || "Unknown User";
			//  alert(name);
			  searchTextEntry.value = name.trim();
			  
			   searchTextEntry.dispatchEvent(new Event('input', { bubbles: true }));

				  // Simulate the search form submission using the hidden fields
				  const frm_str = document.forms['FCLS1160'];
				  if (frm_str) {
					frm_str.FCLS7051_disp_page_nr.value = 1;
					frm_str.FCLS7051_search_criteria_change.value = 1;
					frm_str.form_cd_submited.value = 'FCLS7051';
					frm_str.FCLS7051_button_search_clicked.value = 1;

					setTimeout(() => {
					  frm_str.submit();
			//		  updateLog(itemId, "in_progress", "Search form submitted programmatically.");
					  updateLog(itemId, "in_progress", "Search form submitted programmatically.",tabId);
					}, 1500);
				  } else {
					updateLog(itemId, "failed", "Translator search form not found.",tabId);
					browser.runtime.sendMessage({ action: "closeThisTab" });

				  }
						  
			   
		});
			  
		
			  
	 

	} else {
	  updateLog(itemId, "failed", "Search input not found.", tabId);
	  browser.runtime.sendMessage({ action: "closeThisTab" });
	  return;
	}




}

function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function JobOfferSubmit(itemId, tabid) {

			const dropdown = getElementByXPath(`//select[starts-with(@id, 'FCLS_Rostering_e_rosterOffersEntity_i_') and contains(@id, '_e_ol_avail_cd')]`);


				
				if (dropdown) {
		 
					
					btnSubmitOfferPath = "/html/body/div[2]/div[4]/form/div/div[2]/input[2]";
					const SubmitButtonOfr = getElementByXPath(btnSubmitOfferPath);
					if (SubmitButtonOfr) {
						//updateLog(itemId, "in_progress", "Submit button after offer found and clicked", tabid);
						
						
						if (window.location.href.includes("ol_order_nr=1")){
							
							updateLog(itemId, "completed", "Final Allocation Complete", tabid);
							
						//	setTimeout(() => {
						//		//updateLog(itemId, "completed", "Final Allocation Complete", tabId);
						//		updateLog(itemId, "in_progress", "Final Allocation Completed", tabid);

						//	}, 1000); // delay of 3000 ms = 3 seconds
							
							setTimeout(() => {
								SubmitButtonOfr.click();	
							}, 1500); // delay of 3000 ms = 3 seconds
				
						}else{
							updateLog(itemId, "in_progress", "Submit button after offer found and clicked", tabid);	

							//setTimeout(() => {
						//		updateLog(itemId, "in_progress", "Submit button after offer found and clicked", tabid);	
						//	}, 2000); // delay of 3000 ms = 3 seconds
							
							setTimeout(() => {
								SubmitButtonOfr.click();	
							}, 1500); // delay of 3000 ms = 3 seconds
						}
						
							
							
								
						
					} else{
						updateLog(itemId, "failed", "Allocation submit button not found", tabid);
					}
					
					 
					 
					//const url = window.location.href;
					//if url 
					
					
				}
}


async function runSourceCheck(itemId='',tabid='') {
	
		updateLog(itemId, "in_progress", "Checking source", tabid);			
			
		
		var Source_Path = '//*[@id="Atts2"]';
		
		//updateLog(itemId, "completed", "Source Document Found", tabId);
		
		const SourceD = getElementByXPath(Source_Path, document);
	//	if (headerType && headerType.textContent.includes(', TRN')){
		if (SourceD){
		
							
				 const text = SourceD.innerHTML; // or textContent, but innerHTML is better here to include tags
				// alert(text);

					// Regex: look for 'Translator:' followed by optional spaces, then <b>…</b>
					//const match = text.match(/Translator:\s*<b>(.*?)<\/b>/gm);
					const match = text.match(/\d+ File/);
					if (match) {
						//updateLog(itemId, "completed", "Source Document Found", tabid);
						
						setTimeout(() => {
							updateLog(itemId, "completed", "Source Document Found", tabid);
						}, 2000); // delay of 3000 ms = 3 seconds
						
						
						setTimeout(() => {
							const PathEXit = '/html/body/div[2]/div[4]/form/div/div[2]/input[2]';
							const btnExit = getElementByXPath(PathEXit, document);
							btnExit.click();
						}, 3000); // delay of 3000 ms = 3 seconds
						
					
						
						
					}else{
						//updateLog(itemId, "failed", "Source Document Missing", tabid);
						
						setTimeout(() => {
							updateLog(itemId, "failed", "Source Document Missing", tabid);
						}, 2000); // delay of 3000 ms = 3 seconds
					
						
					}
					
					
		}

		
}
	
	



async function runAutomationStep(itemId='',tabid='') {
	
	//browser.storage.local.get("automationPanelName").then(result => {
		browser.storage.local.get([
		  "automationPanelName",
		  "automationDueFromTranslator",
		  "automationDueToClient"
			]).then(result => {
	
		const name = result.automationPanelName || "Unknown User";
		
		let dueFromTrn = result.automationDueFromTranslator || "";
		let dueToRelease = result.automationDueToClient || "";
		
		var headPath = '//*[@id="sys_desc"]';
		
		var run_it = true;
			
			
		const headerType = getElementByXPath(headPath, document);
	//	if (headerType && headerType.textContent.includes(', TRN')){
		if (headerType){
		
							
				 const text = headerType.innerHTML; // or textContent, but innerHTML is better here to include tags

					// Regex: look for 'Translator:' followed by optional spaces, then <b>…</b>
					//const match = text.match(/Translator:\s*<b>(.*?)<\/b>/gm);
					const match = text.match(/Translator:\s*<b>(.*?)<\/b>/);
					if (match && match[1]) {
						const panelTranslatorName = match[1].trim();
					//	alert(panelTranslatorName);
						if (panelTranslatorName.toLowerCase() === name.trim().toLowerCase()) {
							run_it = true;
							updateLog(itemId, "in_progress", "Matching Panel Found", tabid);
							//updateLog(itemId, "in_progress", "Submit button to Manual Withdraw clicked", tabId);
							
							//updateLog(itemId, "in_progress", "Manual Withdraw clicked", tabId);
						}else{
							run_it = false;
							updateLog(itemId, "failed", "Matching Panel NOT Found", tabid);
						}
					}

				
					
			  
			  // Step 1: Input comment
			  const textPath = "/html/body/div[2]/div[4]/form/div/fieldset[1]/div[1]/div/textarea";
			  const textarea = getElementByXPath(textPath);

			  if (textarea) {
			    textarea.value = "To redistribute job";
			  }



				var PushtoPath = "/html/body/div[2]/div[4]/form/div/div[4]/div[1]/select";
				var selectPushtoPathElement = getElementByXPath(PushtoPath, document);

				if (selectPushtoPathElement) {
					
					//var option = Array.from(selectPushtoPathElement.options).find(option => option.value === "Manual allocation");
					//if (option) {
						//selectPushtoPathElement.value = "Manual allocation";
					    selectPushtoPathElement.value = "S209";
					 
						
						selectPushtoPathElement.dispatchEvent(new Event("change", { bubbles: true }));
						//updateLog(itemId, "in_progress", "Push to Manual Menu Selected", tabid);
					//}
				}

			
					 
					const fromInput = getElementByXPath('//*[@id="LS_BookingTranslation_e_trnBD_e_rtn_ls_date_tm_dt"]',document);	
					
					if (fromInput && dueFromTrn) {
						
					 
						fromInput.value = dueFromTrn;
						
						// Trigger all handlers:
						fromInput.dispatchEvent(new Event('change', { bubbles: true }));
						fromInput.dispatchEvent(new Event('blur', { bubbles: true }));
						fromInput.dispatchEvent(new Event('input', { bubbles: true })); 
										 
					} 
					
					const fromInputD = getElementByXPath('//*[@id="LS_BookingTranslation_e_trnBD_e_rtn_cl_date_tm_dt"]',document);	
					
					if (fromInputD && dueToRelease) {
						
					 
						fromInputD.value = dueToRelease;
						
						// Trigger all handlers:
						fromInputD.dispatchEvent(new Event('change', { bubbles: true }));
						fromInputD.dispatchEvent(new Event('blur', { bubbles: true }));
						fromInputD.dispatchEvent(new Event('input', { bubbles: true })); 
										 
					} 



			  // Step 2: Click the button - Manual status allocated TRN
			  const btnSubmit = "/html/body/div[2]/div[4]/form/div/div[2]/input[1]";
			  const btnExit = "/html/body/div[2]/div[4]/form/div/div[2]/input[2]";
			  
			
			  
			  const btn = getElementByXPath(btnSubmit);
			  const btnE = getElementByXPath(btnExit);
			 // const btn = getElementByXPath(btnSubmit);
				
				//updateLog(itemId, "in_progress", "Almost", tabId);
			  if ((btn) && (run_it == true)) {
					btn.click();
					updateLog(itemId, "in_progress", "Manual Withdraw clicked", tabid);
					//btnE.click();
			}else{
				// browser.runtime.sendMessage({ action: "closeThisTab" });
				//alert('no button');
			}
		
		//  var xpathSubmitButton = "/html/body/div[2]/div[4]/form/div/div[2]/input[2]";
			
	  
		}
			
			
	});
	
	
}



async function runSpecificPanelStep(itemId='',tabid='') {
	
	browser.storage.local.get("automationUserName").then(result => {
			const name = result.automationUserName || "Unknown User";
			
			var panelPath = '/html/body/div[2]/div[4]/form/div/fieldset[1]/div[1]/div/input';
	  
			const panelName = getElementByXPath(panelPath, document);
			//alert(panelName.value);
			//alert(name);
			if (panelName && panelName.value.trim().toLowerCase() === name.trim().toLowerCase()) {
			
				   updateLog(itemId, "in_progress", "Matching Panel Found", tabid);
				
										
					
				//const dropdown = getElementByXPath(`//select[starts-with(@id, 'FCLS_Rostering_e_rosterOffersEntity_i_') and contains(@id, '_e_ol_avail_cd')]`);
				
				
				const dropdown = getElementByXPath(`//select[starts-with(@id, 'FCLS_Rostering_e_rosterOffersEntity_i_') and contains(@id, '_e_ol_avail_cd')]`);


				
				if (dropdown) {
					//dropdown.value = 'NOT_AVAILABLE'; // Or 'NOT_AVAILABLE'
					
					dropdown.focus();
					
					dropdown.value = 'AVAILABLE'; // Or 'NOT_AVAILABLE'
					
					dropdown.dispatchEvent(new Event('input', { bubbles: true }));
					dropdown.dispatchEvent(new Event('change', { bubbles: true }));
					//await delay(1500); 
					dropdown.focus();
					//
					
				
				
				setTimeout(() => {
					JobOfferSubmit(itemId, tabid);
				}, 3000); // delay of 3000 ms = 3 seconds
				
				//JobOfferSubmit();
				

				//updateLog(itemId, "in_progress", "Matching Panel Found", tabid);
			} else {
				//alert('Found panel not matching the target panel');
				updateLog(itemId, "failed", "Matching Panel NOT Found", tabid);
				browser.runtime.sendMessage({ action: "closeThisTab" });				
			}
		}	
	});
	
}



function runSpecificPanelReason(itemId='',tabid='') {
	
//	updateLog(itemId, "in_progress", "Matching Panel Found", tabid);
//	updateLog(itemId, "failed", "Matching Panel NOT Found", tabid);
	
	var ReasonPath = "/html/body/div[2]/div[4]/form/div/div[4]/div[1]/select";
	var selectReasonElement = getElementByXPath(ReasonPath, document);

	if (selectReasonElement) {
	
			selectReasonElement.value = "S209";
			selectReasonElement.dispatchEvent(new Event("change", { bubbles: true }));
	
	
			SubmitButtonPath =  '//*[@id="LS_BookingTranslation_e_LSB_e_dir_lang_cd_disp1"]';
			const SubmitButton = getElementByXPath(SubmitButtonPath);

			if (SubmitButton) {
				SubmitButton.click();
			} else{
				updateLog(itemId, "failed", "Allocation submit button not found", tabid);
			}

	
	} else {
		updateLog(itemId, "failed", "Error picking allocation reason", tabid);
	}

	
}

async function runSelfWithdrawal(itemId = '', tabid = '') {
	var headPath = '//*[@id="sys_desc"]';
	const headerType = getElementByXPath(headPath, document);

	if (headerType && headerType.textContent.includes(', TRN')) {
		var reasonPath = "//select[@name='reason_cd']";
		var selectReasonElement = getElementByXPath(reasonPath, document);

		if (selectReasonElement) {
			var option = Array.from(selectReasonElement.options).find(option => option.value === "HOLIDAY");
			if (option) {
				selectReasonElement.value = option.value;
				updateLog(itemId, "in_progress", "Holiday reason picked", tabid);
			}
		}

		var xpathExitButton = "/html/body/div[2]/div[4]/form/div/div[2]/input[1]";
		var xpathSubmitButton = "/html/body/div[2]/div[4]/form/div/div[2]/input[2]";
		
		var buttonS = getElementByXPath(xpathSubmitButton, document);
		//var buttonS = getElementByXPath(xpathExitButton, document);

		if (buttonS) {
			const result = await browser.storage.local.get("automationPanelName");
			let name = result.automationPanelName || "Unknown User";
			name = name.trim();

			if (headerType.textContent.includes(name)) {
				setTimeout(() => {
						updateLog(itemId, "completed", "Exit Withdrawal clicked", tabid);			
				}, 3000);
				
				setTimeout(() => {
					buttonS.click();				
					}, 4000);
				
				//await delay(500); // now delay will happen after button click
				
			} else {
				updateLog(itemId, "failed", "Panel name not matched", tabid);
				browser.runtime.sendMessage({ action: "closeThisTab" });
				return;
			}
		} else {
			updateLog(itemId, "failed", "Submit button for Withdrawal not found", tabid);
			browser.runtime.sendMessage({ action: "closeThisTab" });
			return;
		}
	} else {
		updateLog(itemId, "failed", "Withdrawal step failed - something went wrong", tabid);
		browser.runtime.sendMessage({ action: "closeThisTab" });
		return;
	}
}



function runTargetAllocation(itemId = '',tabId = '') {
  // You can now perform actions on the redirected page
 // updateLog(itemId, "failed", "Search button not found.");
 
	headPath = '//*[@id="sys_desc"]';
	OptPath = "/html/body/div[2]/div[4]/form/div/table/tbody/tr/td/table/tbody/tr/td/div[1]/span/div";  
	 const headerType = getElementByXPath(headPath, document);
	 const OptCheck = getElementByXPath(OptPath, document);
	 
	if (headerType && headerType.textContent.includes(', TRN') && OptCheck.textContent.includes('Optimised list')){
						//alert("TRN");
	//
	
		//alert('TRN');
	//	if {!headerType.textContent.includes('Manual Allocation')){
	//					updateLog(itemId, "failed", "Withdrawal process may have failed earlier",tabId);
	//		return;
	//	}
		
		const firstRow = document.querySelector('tr[id="0"]');

		// Click the first <a> tag inside that row
		if (firstRow) {
		  const firstLink = firstRow.querySelector('a');
		  if (firstLink) {
			
			updateLog(itemId, "in_progress", "Priority translator found", tabId);
			firstLink.click();
		  } else {
			updateLog(itemId, "failed", "Panel list empty? Check if panel is available",tabId);
								browser.runtime.sendMessage({ action: "closeThisTab" });
 		  }
		} else {
		  updateLog(itemId, "failed", "Optimized list empty? Check if panel is available",tabId);
		  					browser.runtime.sendMessage({ action: "closeThisTab" });
		}
  
	 } else {
 		  updateLog(itemId, "failed", "Optimized list empty? Check if panel is available",tabId);

		browser.runtime.sendMessage({ action: "closeThisTab" });
	 }

  
}


  
  function waitForXPathText(xpath, expectedText, timeout = 5000, interval = 500) {
  return new Promise((resolve, reject) => {
    const startTime = Date.now();

    const check = () => {
      const element = getElementByXPath(xpath);
      if (element && element.textContent.includes(expectedText)) {
        resolve(element); // Found it!
      } else if (Date.now() - startTime >= timeout) {
        reject("Timed out waiting for XPath text match.");
      } else {
        setTimeout(check, interval);
      }
    };

    check();
  });
}

// Utility function to get an element by XPath
function getElementByXPath(xpath, doc = document) {
  return doc.evaluate(xpath, doc, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
}

// Listen for a message to trigger automation
browser.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log("Received action: " + message.action); // Using console.log instead of alert for better debugging
  if (message.action === "runAutomationStep") {
    //runAutomationStep();
	
	 runAutomationStep(message.itemId,message.tabId);
  }
  
  if (message.action === "runSelfWithdrawal") {
    runSelfWithdrawal(message.itemId,message.tabId);
  }

  if (message.action === "runSourceCheck") {
    //runAutomationStep();
	
	 runSourceCheck(message.itemId,message.tabId);
  }
  
});




//window.addEventListener('load', () => {

	const url = window.location.href;
	const xID = getItemIdFromURL();
	const matchIdUrl = false;
	
	
	
	browser.storage.local.get("automationLogsX1").then((result) => {
		  const logs = result.automationLogsX1 || {};
		  const logs2 = result.automationLogsX1 || [];
		  
		  const iID = JSON.stringify(logs, null, 2);

	///	  if (iID.includes(xID)) {
		//	  matchIdUrl = true;
	//	  }
			  
		//	  alert(xID);
	//	const matchId = logs.find(log => log.xID === xID);
		const matchLog = logs2.find(log => log.xID === xID);
		//if (!logs2[xID]) {
		//	 alert('718');
			 
		//if (!matchLog) {
		//	alert(xID);
			itemId = xID;
			//alert('723');
			if (url.toLowerCase().includes("app_form_cd=fcls1018")) {
			  // runAutomationStep();
							
				
				if (!matchLog) {
					if (url.toLowerCase().includes("app_form_cd=fcls1018")) {
				  // runAutomationStep();
					
				//					alert('Without log');
									
						const HeaderXpath = '//*[@id="sys_desc"]';
						const headerType = getElementByXPath(HeaderXpath);
						
						if (headerType && headerType.textContent.includes(', TRN') && headerType.textContent.toLowerCase().includes('english to')){

							radioButtonPath =  '//*[@id="LS_BookingTranslation_e_LSB_e_dir_lang_cd_disp1"]';
							const radioButton = getElementByXPath(radioButtonPath);

							if (radioButton) {
								radioButton.click();
							}
						}else if (headerType && headerType.textContent.includes(', TRN') && headerType.textContent.toLowerCase().includes(', non standard doc')){
							//alert('Non std');
							radioButtonPath =  '//*[@id="LS_BookingTranslation_e_LSB_e_dir_lang_cd_disp0"]';
							const radioButton = getElementByXPath(radioButtonPath);

							if (radioButton) {
								radioButton.click();
							}	
						} else if (headerType && headerType.textContent.includes(', TRN') && headerType.textContent.includes(', Standard Doc')){
							
							
							
							radioButtonPath =  '//*[@id="LS_BookingTranslation_e_LSB_e_dir_lang_cd_disp0"]';
							const radioButton = getElementByXPath(radioButtonPath);

							if (radioButton) {
								radioButton.click();
							}
						}
						
						if (headerType && headerType.textContent.includes('Manual Allocation')){
							const dateXpath = '//*[@id="LS_BookingTranslation_e_trnBD_e_rtn_ls_date_tm_dt"]';
							const dateXpathElement = getElementByXPath(dateXpath);
							
							if (dateXpathElement) {
								const dateText = dateXpathElement.value.trim(); // Assuming it's an <input> or similar
								console.log("Found date:", dateText);

								// Parse the "DD/MM/YYYY" format into a Date object
								const [day, month, year] = dateText.split('/').map(Number);
								const parsedDate = new Date(year, month - 1, day); // month is 0-based

								const today = new Date();
								// Set today's time to 00:00:00 so we compare dates only
								today.setHours(0, 0, 0, 0);

								if (parsedDate < today) {
									console.log("The date is older than today.");
									//alert("Older date found!");
									showNotificationBootstrapNotify("Please check and change date of return to client");
									showNotificationBootstrapNotify("Please check translator's due date as well");
									
									hPath = '/html/body/div[2]/div[4]/form/div/div[6]/fieldset[4]/div[2]/div/label';
									elHpath = getElementByXPath(hPath);
									highlightElement(elHpath);
									hPath2 = '/html/body/div[2]/div[4]/form/div/div[6]/fieldset[4]/div[4]/div/label';
									elHpath2 = getElementByXPath(hPath2);
									highlightElement(elHpath2);
								} 
							}
						
						
					}			
				  }
				}
				
			} else if (url.includes("app_form_cd=FCLS1087")){
				//alert();
				/*/
				
				 browser.runtime.sendMessage({ action: "getMyTabId" }).then(response => {
					  const myTabId = response.tabId;
									 
					  getMessageByTabId(myTabId).then((msg) => {
						 // alert(msg + " " + myTabId);
						 if (msg.includes("Tab opened")){
							// alert(msg + " " + myTabId);
							updateLog(itemId, "in_progress", "Withdrawal process begins", myTabId);
							runSelfWithdrawal(itemId,myTabId);
						 }
						});
	//				   
				});
				
				/*/
				
				
			} else if (url.includes("app_form_cd=FCLS1160")) {
				//*/
				browser.runtime.sendMessage({ action: "getMyTabId" }).then(response => {
					  const myTabId = response.tabId;
					  
						getItemIDByTabId(myTabId).then((itemId) => {
							//
							if (itemId) {
								runAllocationStep(itemId,myTabId);
							}else{
								//alert('unmatched');	
							}
						});
				
				});
				
			 
				
			  
			} else if (url.includes("app_form_cd=FCLS1161")) {
				//alert('Specific TRN');
				
				browser.runtime.sendMessage({ action: "getMyTabId" }).then(response => {
					  const myTabId = response.tabId;
					   
						getItemIDByTabId(myTabId).then((itemId) => {
								//alert(myTabId);
								//alert(itemId);
								if (itemId) {
									updateLog(itemId, "in_progress", "Navigating Panel Allocation List", myTabId);	
									runSpecificPanelStep(itemId,myTabId);
								}
						});
						
	  
				});
				
			} else if (url.includes("app_form_cd=XXX")) {
				//alert('Specific TRN');
				
				browser.runtime.sendMessage({ action: "getMyTabId" }).then(response => {
					  const myTabId = response.tabId;
					   
						getItemIDByTabId(myTabId).then((itemId) => {
								//alert(myTabId);
								//alert(itemId);
								if (itemId) {
									updateLog(itemId, "in_progress", "Sorting reason for allocation", myTabId);	
									runSpecificPanelStep(itemId,myTabId);
								}
							
						});
						
	  
				});		
				   
			//} // end of check
			
			
			
		  } else {
		 
			  if ((url.includes("https://www.crclanguagelink.com.au/index.php")) || (url.includes("https://www.crclanguagelink.com.au/sys003.htm?app_cd=SYS")) || (url === 'https://www.crclanguagelink.com.au/index.php?app_form_cd=SYS135')){
//				 if ((url === "https://www.crclanguagelink.com.au/index.php?app_form_cd=SYS135")|| (url === "https://www.crclanguagelink.com.au/index.php") || (url === "https://www.crclanguagelink.com.au/sys003.htm?app_cd=SYS&app_ver_id=1&app_form_cd=SYS135&_template=advanced&_action=switch_menu&_action=switch_menu&menu_item_cd=ACT_LIST&menu_cd=ACTIVE_LIST") || (url.includes("https://www.crclanguagelink.com.au/sys003.htm?app_cd=SYS"))){  
				 // alert(url);
				  
				 browser.runtime.sendMessage({ action: "getMyTabId" }).then(response => {
					  const myTabId = response.tabId;
					
					  //msg = getMessageByTabId(myTabId);
					  
					  
					  getMessageByTabId(myTabId).then((msg) => {
						 // alert(msg + " " + myTabId);
						 if (msg.includes("Exit Now")){
							 //alert(msg + " " + myTabId);
							 
							// browser.runtime.sendMessage({
							//	action: "closeThisTab"
							//	});	
							//updateLog(itemId, "completed", "Withdrawal Complete", myTabId);
							browser.runtime.sendMessage({ action: "closeThisTab" });
							
						 }
						 
						 if (msg.includes("Final Allocation Complete")){
							browser.runtime.sendMessage({ action: "closeThisTab" });
							
						 }
						 
						 if (msg.includes("Final Allocation Complete")){
							browser.runtime.sendMessage({ action: "closeThisTab" });
							
						 }
						 
						 
						  if (msg.includes("Source Document Found")){
							browser.runtime.sendMessage({ action: "closeThisTab" });
							
						 }
						
						 
						 if (msg.includes("Exit Withdrawal")){
							 
							getItemIDByTabId(myTabId).then((itemId) => {

							
								//alert(itemId);
								    if (itemId) { 
										updateLog(itemId, "completed", "Withdrawal Complete", myTabId);
										//updateLog(itemId, "in_progress", "Closing", myTabId);
										browser.runtime.sendMessage({ action: "closeThisTab" });
									}
							});
						 }
						});
	 
				});
			  }

				if (url === "https://www.crclanguagelink.com.au/index.php"){
					
					//OverridePath = '/html/body/div[2]/div[4]/form/div/fieldset/legend/mark';
					OverridePath = '/html/body/div[2]/div[4]/form/div/fieldset/legend';
					
					
					
					 const OverridePage = getElementByXPath(OverridePath, document);
					if (OverridePage && OverridePage.textContent.includes('Override priority list')){
						//alert(OverridePath);
						//alert('Trigger for override is found');
						const itemIdP = "/html/body/div[2]/div[3]/div[1]";
						const element = getElementByXPath(itemIdP);
						if (element) {
							const text = element.textContent;
							const match = text.match(/\b3\d{6}\b/); // Only match 7-digit numbers starting with 3
							//alert('STep 1');
							
							if (match) {
								itemId = match[0]; // Return the first match
								const matchId = logs.find(log => log.itemId === itemId);
								
							//	alert('STep 2');
							    if (matchId){
								  
								//alert('STep 3');
							
									browser.runtime.sendMessage({ action: "getMyTabId" }).then(response => {
											const tabId = response.tabId;
											
											getTabIdByItemId(itemId).then((tabId) => {
												if (tabId) {
													const selectElementReason = getElementByXPath('/html/body/div[2]/div[4]/form/div/fieldset/div[1]/div/select');

													if (selectElementReason) {
														//await sleep(1500);
														// Set the value to "OTH"
														selectElementReason.value = "OTH";
														updateLog(itemId, "in_progress", "Overriding Reason Selected", tabId);

														// Dispatch the change event to trigger any listeners
														const event = new Event('change', { bubbles: true });
														selectElementReason.dispatchEvent(event);
													//	waitforme();
														
														butnContinuePath = '/html/body/div[2]/div[4]/form/div/div[2]/input[2]';
														
														 const btnContinue = getElementByXPath(butnContinuePath);
			  

														  if (btnContinue) {
														
																	btnContinue.click();
																	//updateLog(itemId, "in_progress", "Submission Withdraw", tabId);
																	updateLog(itemId, "completed", "Final Allocation Complete", tabId);
																	
														}
														
//
														 
													}
												}
											});
	
											
									});
								   
								}
								
							}
							
						}
						//alert(itemId);
					}
					
							
				}
				
				if (url === "https://www.crclanguagelink.com.au/index.php"){
					//const HeaderXpath = "/html/body/div[2]/div[4]/form/div/table/tbody/tr/td/table/tbody/tr/td/div[1]/span/div";
					const HeaderXpath =  "/html/body/div[2]/div[4]/form/div/table/tbody/tr/td";
					
					waitForXPathText(HeaderXpath, "Optimised list")
						.then(() => {
							
							headPath = '//*[@id="sys_desc"]';
							
							  
							 const headerType = getElementByXPath(headPath, document);
								if (headerType && headerType.textContent.includes(', TRN')){
									
									  const text = headerType.textContent;
									  const findTRN = text.match(/\b\d{7}\b/); // any 7-digit number
										  
									  if (findTRN) {
										  //alert(match);
										  const itemId = findTRN[0];
										  
										  const matchId = logs.find(log => log.itemId === itemId);
										    
										    
										  if (matchId){
											  //alert(itemId);
											    
												getTabIdByItemId(itemId).then((tabId) => {
													    if (tabId) {
														 
															updateLog(itemId, "in_progress", "Sending to Target Allocation", tabId);
															runTargetAllocation(itemId,tabId); // <-- run after match
														}
												});
												  
										  }else{
											  updateLog(itemId, "failed", "Unable to finalize",tabId);
											  browser.runtime.sendMessage({ action: "closeThisTab" });
											  
										  }
										  
									  }
									
								}
						  
						  
						  
						  
						})
						.catch((err) => {
							//updateLog(itemId, "failed", "Unable to finalize");
						  //alert('Element not found or did not contain "Optimised list"');
						});
						
						
				}
				

				if ((url === "https://www.crclanguagelink.com.au/index.php?app_form_cd=SYS135") || (window.location.href.includes("https://www.crclanguagelink.com.au/sys003.htm?app_cd=SYS&app_ver_id=1&app_form_cd=SYS135"))) {
//						alert('1100');
					 browser.runtime.sendMessage({ action: "getMyTabId" }).then(response => {
					  const myTabId = response.tabId;
					
					  //msg = getMessageByTabId(myTabId);
					  
					  
					  getMessageByTabId(myTabId).then((msg) => {
						 // alert(msg + " " + myTabId);
						 if (msg.includes("Manual Withdraw clicked")){
							
							getItemIDByTabId(myTabId).then((itemId) => {
								    if (itemId) {
										updateLog(itemId, "in_progress", "Allocation process begins", myTabId);

										const targetURL = `https://www.crclanguagelink.com.au/index.php?app_form_cd=FCLS1160&prcs_defn_cd=&_template=default&_al_action_click=1&mode=edit&state_cd=&app_cd=&item_id=${itemId}&bypass`;
										window.location.href = targetURL;
									}
							});
						 }
						 
						 
						});

					  
					});
						
				}
		  
		  
	  }
	});
//}  
  
